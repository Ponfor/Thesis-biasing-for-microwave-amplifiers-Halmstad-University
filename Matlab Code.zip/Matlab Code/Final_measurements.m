%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%OP Amps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for LT6220_0402_Avar = 1
%%%%%%%%%%%%%%%%%%%%%%%%
%LT6220 0402 allan variance
%%%%%%%%%%%%%%%%%%%%%%%%
LT6220_0402_AllanVariance = readmatrix('LT6220/Allan Variance 0402.csv', 'Delimiter', ';');

%Current
LT6220_0402_AllanVariance_current_f = LT6220_0402_AllanVariance(:,3);
LT6220_0402_AllanVariance_current_amp = LT6220_0402_AllanVariance(:,4);

%Power Detector
LT6220_0402_AllanVariance_PDET_f = LT6220_0402_AllanVariance(:,5);
LT6220_0402_AllanVariance_PDET_amp = LT6220_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

%Vd
LT6220_0402_AllanVariance_Vd_f = LT6220_0402_AllanVariance(:,11);
LT6220_0402_AllanVariance_Vd_amp = LT6220_0402_AllanVariance(:,12) + 20*log10(2/0.891);
%%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_0402_DClevel = 1
%%%%%%%%%%%%%%%%%%%%%%%%
%LT6220 0402 dc level
%%%%%%%%%%%%%%%%%%%%%%%%
LT6220_0402_DC = readmatrix('LT6220/DC Level 0402.csv', 'Delimiter', ';');

%Current
LT6220_0402_DC_current_f = LT6220_0402_DC(:,1);
LT6220_0402_DC_current_amp = LT6220_0402_DC(:,2);

%Power Detector
LT6220_0402_DC_PDET_f = LT6220_0402_DC(:,3);
LT6220_0402_DC_PDET_amp = (2.856/2.69)*LT6220_0402_DC(:,4);

%Vd
LT6220_0402_DC_Vd_f = LT6220_0402_DC(:,15);
LT6220_0402_DC_vd_amp = (2/0.891)*LT6220_0402_DC(:,16);

%VCC
LT6220_0402_DC_VCC_f = LT6220_0402_DC(:,13);
LT6220_0402_DC_VCC_amp = (4/0.916)*LT6220_0402_DC(:,14);
%%%%%%%%%%%%%%%%%%%%%%%%

    %{
    figure(3);
    currentDC = plot(LT6220_0402_DC_current_f, LT6220_0402_DC_current_amp);
    hold on
    PDETDC = plot(LT6220_0402_DC_PDET_f, LT6220_0402_DC_PDET_amp);
    VdDC = plot(LT6220_0402_DC_Vd_f, LT6220_0402_DC_vd_amp);
    VCCC = plot(LT6220_0402_DC_VCC_f, LT6220_0402_DC_VCC_amp);
    legend([currentDC, PDETDC, VdDC, VCCC], {'Current', 'Power Detector', 'Vd',  'VCC'})
    grid on
    title('DC Levels')
    xlabel('Frequency [Hz]')
    ylabel('Amplitude')
    yticks(-1:0.2:12)
    ylim([-1 12])
    hold off
    %}


end

for LT6220_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_0402_history = readmatrix('LT6220/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    LT6220_0402_history_current_f = LT6220_0402_history(:,1);
    LT6220_0402_history_current_amp = LT6220_0402_history(:,2);

    %Power Detector
    LT6220_0402_history_PDET_f = LT6220_0402_history(:,3);
    LT6220_0402_history_PDET_amp = (2.856/2.69)*LT6220_0402_history(:,4);

    %Vd
    LT6220_0402_history_Vd_f = LT6220_0402_history(:,15);  
    LT6220_0402_history_Vd_amp = (2/0.916)*LT6220_0402_history(:,16);



    figure(1);
    currenthistory = semilogx(LT6220_0402_history_current_f, LT6220_0402_history_current_amp);
    hold on
    PDEThistory = semilogx(LT6220_0402_history_PDET_f, LT6220_0402_history_PDET_amp);
    Vdhistory = semilogx(LT6220_0402_history_Vd_f, LT6220_0402_history_Vd_amp);
    legend([currenthistory, PDEThistory, Vdhistory], {'Current', 'Power Detector', 'Vd'})
    grid on
    title('History mean spectrum graph of Id, PDET, Vd for LT6220 with 0402 footprints')
    xlabel('Frequency [Hz]')
    ylabel('Amplitude')
    %yticks(0:0.005*10^-5:3*10^-5)
    hold off
end

for LT6220_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_0805_AllanVariance = readmatrix('LT6220/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    LT6220_0805_AllanVariance_current_f = LT6220_0805_AllanVariance(:,3);
    LT6220_0805_AllanVariance_current_amp = LT6220_0805_AllanVariance(:,4);

    %Power Detector
    LT6220_0805_AllanVariance_PDET_f = LT6220_0805_AllanVariance(:,5);
    LT6220_0805_AllanVariance_PDET_amp = LT6220_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6220_0805_AllanVariance_Vd_f = LT6220_0805_AllanVariance(:,11);
    LT6220_0805_AllanVariance_Vd_amp = LT6220_0805_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_0805_DC = readmatrix('LT6220/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    LT6220_0805_DC_current_f = LT6220_0805_DC(:,1);
    LT6220_0805_DC_current_amp = LT6220_0805_DC(:,2);

    %Power Detector
    LT6220_0805_DC_PDET_f = LT6220_0805_DC(:,3);
    LT6220_0805_DC_PDET_amp = (2.856/2.69)*LT6220_0805_DC(:,4);

    %Vd
    LT6220_0805_DC_Vd_f = LT6220_0805_DC(:,15);
    LT6220_0805_DC_vd_amp = (2/0.891)*LT6220_0805_DC(:,16);

    %VCC
    LT6220_0805_DC_VCC_f = LT6220_0805_DC(:,13);
    LT6220_0805_DC_VCC_amp = (4/0.916)*LT6220_0805_DC(:,14);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_0805_history = readmatrix('LT6220/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    LT6220_0805_history_current_f = LT6220_0805_history(:,1);
    LT6220_0805_history_current_amp = LT6220_0805_history(:,2);

    %Power Detector
    LT6220_0805_history_PDET_f = LT6220_0805_history(:,3);
    LT6220_0805_history_PDET_amp = (2.856/2.69)*LT6220_0805_history(:,4);

    %Vd
    LT6220_0805_history_Vd_f = LT6220_0805_history(:,15);  
    LT6220_0805_history_Vd_amp = (2/0.916)*LT6220_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_1206_AllanVariance = readmatrix('LT6220/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    LT6220_1206_AllanVariance_current_f = LT6220_1206_AllanVariance(:,3);
    LT6220_1206_AllanVariance_current_amp = LT6220_1206_AllanVariance(:,4);

    %Power Detector
    LT6220_1206_AllanVariance_PDET_f = LT6220_1206_AllanVariance(:,5);
    LT6220_1206_AllanVariance_PDET_amp = LT6220_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6220_1206_AllanVariance_Vd_f = LT6220_1206_AllanVariance(:,17);
    LT6220_1206_AllanVariance_Vd_amp = LT6220_1206_AllanVariance(:,18) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_1206_DC = readmatrix('LT6220/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    LT6220_1206_DC_current_f = LT6220_1206_DC(:,1);
    LT6220_1206_DC_current_amp = LT6220_1206_DC(:,2);

    %Power Detector
    LT6220_1206_DC_PDET_f = LT6220_1206_DC(:,3);
    LT6220_1206_DC_PDET_amp = (2.856/2.69)*LT6220_1206_DC(:,4);

    %Vd
    LT6220_1206_DC_Vd_f = LT6220_1206_DC(:,15);
    LT6220_1206_DC_vd_amp = (2/0.891)*LT6220_1206_DC(:,16);

    %VCC
    LT6220_1206_DC_VCC_f = LT6220_1206_DC(:,13);
    LT6220_1206_DC_VCC_amp = (4/0.916)*LT6220_1206_DC(:,14);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6220_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6220 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6220_1206_history = readmatrix('LT6220/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    LT6220_1206_history_current_f = LT6220_1206_history(:,1);
    LT6220_1206_history_current_amp = LT6220_1206_history(:,2);

    %Power Detector
    LT6220_1206_history_PDET_f = LT6220_1206_history(:,3);
    LT6220_1206_history_PDET_amp = (2.856/2.69)*LT6220_1206_history(:,4);

    %Vd
    LT6220_1206_history_Vd_f = LT6220_1206_history(:,15);  
    LT6220_1206_history_Vd_amp = (2/0.916)*LT6220_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end





for ADA4805_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0402_AllanVariance = readmatrix('ADA4805/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    ADA4805_0402_AllanVariance_current_f = ADA4805_0402_AllanVariance(:,3);
    ADA4805_0402_AllanVariance_current_amp = ADA4805_0402_AllanVariance(:,4);

    %Power Detector
    ADA4805_0402_AllanVariance_PDET_f = ADA4805_0402_AllanVariance(:,5);
    ADA4805_0402_AllanVariance_PDET_amp = ADA4805_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    ADA4805_0402_AllanVariance_Vd_f = ADA4805_0402_AllanVariance(:,17);
    ADA4805_0402_AllanVariance_Vd_amp = ADA4805_0402_AllanVariance(:,18) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0402_DC = readmatrix('ADA4805/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    ADA4805_0402_DC_current_f = ADA4805_0402_DC(:,1);
    ADA4805_0402_DC_current_amp = ADA4805_0402_DC(:,2);

    %Power Detector
    ADA4805_0402_DC_PDET_f = ADA4805_0402_DC(:,3);
    ADA4805_0402_DC_PDET_amp = (2.856/2.69)*ADA4805_0402_DC(:,4);

    %Vd
    ADA4805_0402_DC_Vd_f = ADA4805_0402_DC(:,15);
    ADA4805_0402_DC_vd_amp = (2/0.891)*ADA4805_0402_DC(:,16);

    %VCC
    ADA4805_0402_DC_VCC_f = ADA4805_0402_DC(:,13);
    ADA4805_0402_DC_VCC_amp = (4/0.916)*ADA4805_0402_DC(:,14);
    %%%%%%%%%%%%%%%%%%%%%%%%

    %{
    figure(3);
    currentDC = plot(LT6220_0402_DC_current_f, LT6220_0402_DC_current_amp);
    hold on
    PDETDC = plot(LT6220_0402_DC_PDET_f, LT6220_0402_DC_PDET_amp);
    VdDC = plot(LT6220_0402_DC_Vd_f, LT6220_0402_DC_vd_amp);
    VCCC = plot(LT6220_0402_DC_VCC_f, LT6220_0402_DC_VCC_amp);
    legend([currentDC, PDETDC, VdDC, VCCC], {'Current', 'Power Detector', 'Vd',  'VCC'})
    grid on
    title('DC Levels')
    xlabel('Frequency [Hz]')
    ylabel('Amplitude')
    yticks(-1:0.2:12)
    ylim([-1 12])
    hold off
    %}


end

for ADA4805_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0402_history = readmatrix('ADA4805/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    ADA4805_0402_history_current_f = ADA4805_0402_history(:,1);
    ADA4805_0402_history_current_amp = ADA4805_0402_history(:,2);

    %Power Detector
    ADA4805_0402_history_PDET_f = ADA4805_0402_history(:,3);
    ADA4805_0402_history_PDET_amp = (2.856/2.69)*ADA4805_0402_history(:,4);

    %Vd
    ADA4805_0402_history_Vd_f = ADA4805_0402_history(:,15);  
    ADA4805_0402_history_Vd_amp = (2/0.916)*ADA4805_0402_history(:,16);



    figure(1);
    currenthistory = semilogx(LT6220_0402_history_current_f, LT6220_0402_history_current_amp);
    hold on
    PDEThistory = semilogx(LT6220_0402_history_PDET_f, LT6220_0402_history_PDET_amp);
    Vdhistory = semilogx(LT6220_0402_history_Vd_f, LT6220_0402_history_Vd_amp);
    legend([currenthistory, PDEThistory, Vdhistory], {'Current', 'Power Detector', 'Vd'})
    grid on
    title('History mean spectrum graph of Id, PDET, Vd for LT6220 with 0402 footprints')
    xlabel('Frequency [Hz]')
    ylabel('Amplitude')
    %yticks(0:0.005*10^-5:3*10^-5)
    hold off
end

for ADA4805_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0805_AllanVariance = readmatrix('ADA4805/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    ADA4805_0805_AllanVariance_current_f = ADA4805_0805_AllanVariance(:,3);
    ADA4805_0805_AllanVariance_current_amp = ADA4805_0805_AllanVariance(:,4);

    %Power Detector
    ADA4805_0805_AllanVariance_PDET_f = ADA4805_0805_AllanVariance(:,5);
    ADA4805_0805_AllanVariance_PDET_amp = ADA4805_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    ADA4805_0805_AllanVariance_Vd_f = ADA4805_0805_AllanVariance(:,11);
    ADA4805_0805_AllanVariance_Vd_amp = ADA4805_0805_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0805_DC = readmatrix('ADA4805/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    ADA4805_0805_DC_current_f = ADA4805_0805_DC(:,1);
    ADA4805_0805_DC_current_amp = ADA4805_0805_DC(:,2);

    %Power Detector
    ADA4805_0805_DC_PDET_f = ADA4805_0805_DC(:,3);
    ADA4805_0805_DC_PDET_amp = (2.856/2.69)*ADA4805_0805_DC(:,4);

    %Vd
    ADA4805_0805_DC_Vd_f = ADA4805_0805_DC(:,15);
    ADA4805_0805_DC_vd_amp = (2/0.891)*ADA4805_0805_DC(:,16);

    %VCC
    ADA4805_0805_DC_VCC_f = ADA4805_0805_DC(:,13);
    ADA4805_0805_DC_VCC_amp = (4/0.916)*ADA4805_0805_DC(:,14);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_0805_history = readmatrix('ADA4805/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    ADA4805_0805_history_current_f = ADA4805_0805_history(:,1);
    ADA4805_0805_history_current_amp = ADA4805_0805_history(:,2);

    %Power Detector
    ADA4805_0805_history_PDET_f = ADA4805_0805_history(:,3);
    ADA4805_0805_history_PDET_amp = (2.856/2.69)*ADA4805_0805_history(:,4);

    %Vd
    ADA4805_0805_history_Vd_f = ADA4805_0805_history(:,15);  
    ADA4805_0805_history_Vd_amp = (2/0.916)*ADA4805_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_1206_AllanVariance = readmatrix('ADA4805/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    ADA4805_1206_AllanVariance_current_f = ADA4805_1206_AllanVariance(:,3);
    ADA4805_1206_AllanVariance_current_amp = ADA4805_1206_AllanVariance(:,4);

    %Power Detector
    ADA4805_1206_AllanVariance_PDET_f = ADA4805_1206_AllanVariance(:,5);
    ADA4805_1206_AllanVariance_PDET_amp = ADA4805_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    ADA4805_1206_AllanVariance_Vd_f = ADA4805_1206_AllanVariance(:,17);
    ADA4805_1206_AllanVariance_Vd_amp = ADA4805_1206_AllanVariance(:,18) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_1206_DC = readmatrix('ADA4805/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    ADA4805_1206_DC_current_f = ADA4805_1206_DC(:,1);
    ADA4805_1206_DC_current_amp = ADA4805_1206_DC(:,2);

    %Power Detector
    ADA4805_1206_DC_PDET_f = ADA4805_1206_DC(:,3);
    ADA4805_1206_DC_PDET_amp = (2.856/2.69)*ADA4805_1206_DC(:,4);

    %Vd
    ADA4805_1206_DC_Vd_f = ADA4805_1206_DC(:,15);
    ADA4805_1206_DC_vd_amp = (2/0.891)*ADA4805_1206_DC(:,16);

    %VCC
    ADA4805_1206_DC_VCC_f = ADA4805_1206_DC(:,13);
    ADA4805_1206_DC_VCC_amp = (4/0.916)*ADA4805_1206_DC(:,14);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for ADA4805_1206_mean_hiistory = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %ADA4805 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    ADA4805_1206_history = readmatrix('ADA4805/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    ADA4805_1206_history_current_f = ADA4805_1206_history(:,1);
    ADA4805_1206_history_current_amp = ADA4805_1206_history(:,2);

    %Power Detector
    ADA4805_1206_history_PDET_f = ADA4805_1206_history(:,3);
    ADA4805_1206_history_PDET_amp = (2.856/2.69)*ADA4805_1206_history(:,4);

    %Vd
    ADA4805_1206_history_Vd_f = ADA4805_1206_history(:,15);  
    ADA4805_1206_history_Vd_amp = (2/0.916)*ADA4805_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end




for LT6238_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0402_AllanVariance = readmatrix('LT6238/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    LT6238_0402_AllanVariance_current_f = LT6238_0402_AllanVariance(:,3);
    LT6238_0402_AllanVariance_current_amp = LT6238_0402_AllanVariance(:,4);

    %Power Detector
    LT6238_0402_AllanVariance_PDET_f = LT6238_0402_AllanVariance(:,5);
    LT6238_0402_AllanVariance_PDET_amp = LT6238_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6238_0402_AllanVariance_Vd_f = LT6238_0402_AllanVariance(:,17);
    LT6238_0402_AllanVariance_Vd_amp = LT6238_0402_AllanVariance(:,18) + 20*log10(2/0.891);
end 

for LT6238_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0402_DC = readmatrix('LT6238/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    LT6238_0402_DC_current_f = LT6238_0402_DC(:,1);
    LT6238_0402_DC_current_amp = LT6238_0402_DC(:,2);

    %Power Detector
    LT6238_0402_DC_PDET_f = LT6238_0402_DC(:,3);
    LT6238_0402_DC_PDET_amp = (2.856/2.69)*LT6238_0402_DC(:,4);

    %Vd
    LT6238_0402_DC_Vd_f = LT6238_0402_DC(:,15);
    LT6238_0402_DC_vd_amp = (2/0.891)*LT6238_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6238_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0402_history = readmatrix('LT6238/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    LT6238_0402_history_current_f = LT6238_0402_history(:,1);
    LT6238_0402_history_current_amp = LT6238_0402_history(:,2);

    %Power Detector
    LT6238_0402_history_PDET_f = LT6238_0402_history(:,3);
    LT6238_0402_history_PDET_amp = (2.856/2.69)*LT6238_0402_history(:,4);

    %Vd
    LT6238_0402_history_Vd_f = LT6238_0402_history(:,15);  
    LT6238_0402_history_Vd_amp = (2/0.916)*LT6238_0402_history(:,16);
end

for LT6238_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0805_AllanVariance = readmatrix('LT6238/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    LT6238_0805_AllanVariance_current_f = LT6238_0805_AllanVariance(:,3);
    LT6238_0805_AllanVariance_current_amp = LT6238_0805_AllanVariance(:,4);

    %Power Detector
    LT6238_0805_AllanVariance_PDET_f = LT6238_0805_AllanVariance(:,5);
    LT6238_0805_AllanVariance_PDET_amp = LT6238_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6238_0805_AllanVariance_Vd_f = LT6238_0805_AllanVariance(:,11);
    LT6238_0805_AllanVariance_Vd_amp = LT6238_0805_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6238_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0805_DC = readmatrix('LT6238/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    LT6238_0805_DC_current_f = LT6238_0805_DC(:,1);
    LT6238_0805_DC_current_amp = LT6238_0805_DC(:,2);

    %Power Detector
    LT6238_0805_DC_PDET_f = LT6238_0805_DC(:,3);
    LT6238_0805_DC_PDET_amp = (2.856/2.69)*LT6238_0805_DC(:,4);

    %Vd
    LT6238_0805_DC_Vd_f = LT6238_0805_DC(:,15);
    LT6238_0805_DC_vd_amp = (2/0.891)*LT6238_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6238_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_0805_history = readmatrix('LT6238/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    LT6238_0805_history_current_f = LT6238_0805_history(:,1);
    LT6238_0805_history_current_amp = LT6238_0805_history(:,2);

    %Power Detector
    LT6238_0805_history_PDET_f = LT6238_0805_history(:,3);
    LT6238_0805_history_PDET_amp = (2.856/2.69)*LT6238_0805_history(:,4);

    %Vd
    LT6238_0805_history_Vd_f = LT6238_0805_history(:,15);  
    LT6238_0805_history_Vd_amp = (2/0.916)*LT6238_0805_history(:,16);
end

for LT6238_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_1206_AllanVariance = readmatrix('LT6238/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    LT6238_1206_AllanVariance_current_f = LT6238_1206_AllanVariance(:,3);
    LT6238_1206_AllanVariance_current_amp = LT6238_1206_AllanVariance(:,4);

    %Power Detector
    LT6238_1206_AllanVariance_PDET_f = LT6238_1206_AllanVariance(:,5);
    LT6238_1206_AllanVariance_PDET_amp = LT6238_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6238_1206_AllanVariance_Vd_f = LT6238_1206_AllanVariance(:,17);
    LT6238_1206_AllanVariance_Vd_amp = LT6238_1206_AllanVariance(:,18) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6238_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_1206_DC = readmatrix('LT6238/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    LT6238_1206_DC_current_f = LT6238_0805_DC(:,1);
    LT6238_1206_DC_current_amp = LT6238_0805_DC(:,2);

    %Power Detector
    LT6238_1206_DC_PDET_f = LT6238_0805_DC(:,3);
    LT6238_1206_DC_PDET_amp = (2.856/2.69)*LT6238_0805_DC(:,4);

    %Vd
    LT6238_1206_DC_Vd_f = LT6238_0805_DC(:,15);
    LT6238_1206_DC_vd_amp = (2/0.891)*LT6238_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6238_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6238 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6238_1206_history = readmatrix('LT6238/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    LT6238_1206_history_current_f = LT6238_1206_history(:,1);
    LT6238_1206_history_current_amp = LT6238_1206_history(:,2);

    %Power Detector
    LT6238_1206_history_PDET_f = LT6238_1206_history(:,3);
    LT6238_1206_history_PDET_amp = (2.856/2.69)*LT6238_1206_history(:,4);

    %Vd
    LT6238_1206_history_Vd_f = LT6238_1206_history(:,15);  
    LT6238_1206_history_Vd_amp = (2/0.916)*LT6238_1206_history(:,16);
end




for LT6221_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0402_AllanVariance = readmatrix('LT6221/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    LT6221_0402_AllanVariance_current_f = LT6221_0402_AllanVariance(:,3);
    LT6221_0402_AllanVariance_current_amp = LT6221_0402_AllanVariance(:,4);

    %Power Detector
    LT6221_0402_AllanVariance_PDET_f = LT6221_0402_AllanVariance(:,5);
    LT6221_0402_AllanVariance_PDET_amp = LT6221_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6221_0402_AllanVariance_Vd_f = LT6221_0402_AllanVariance(:,11);
    LT6221_0402_AllanVariance_Vd_amp = LT6221_0402_AllanVariance(:,12) + 20*log10(2/0.891);
end 

for LT6221_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0402_DC = readmatrix('LT6221/DC Level 0402.csv', 'Delimiter', ';');
    
    %Current
    LT6221_0402_DC_current_f = LT6221_0402_DC(:,1);
    LT6221_0402_DC_current_amp = LT6221_0402_DC(:,2);
    
    %Power Detector
    LT6221_0402_DC_PDET_f = LT6221_0402_DC(:,3);
    LT6221_0402_DC_PDET_amp = (2.856/2.69)*LT6221_0402_DC(:,4);
    
    %Vd
    LT6221_0402_DC_Vd_f = LT6221_0402_DC(:,15);
    LT6221_0402_DC_vd_amp = (2/0.891)*LT6221_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6221_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0402_history = readmatrix('LT6221/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    LT6221_0402_history_current_f = LT6221_0402_history(:,1);
    LT6221_0402_history_current_amp = LT6221_0402_history(:,2);

    %Power Detector
    LT6221_0402_history_PDET_f = LT6221_0402_history(:,3);
    LT6221_0402_history_PDET_amp = (2.856/2.69)*LT6221_0402_history(:,4);

    %Vd
    LT6221_0402_history_Vd_f = LT6221_0402_history(:,15);  
    LT6221_0402_history_Vd_amp = (2/0.916)*LT6221_0402_history(:,16);
end

for LT6221_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0805_AllanVariance = readmatrix('LT6221/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    LT6221_0805_AllanVariance_current_f = LT6221_0805_AllanVariance(:,3);
    LT6221_0805_AllanVariance_current_amp = LT6221_0805_AllanVariance(:,4);

    %Power Detector
    LT6221_0805_AllanVariance_PDET_f = LT6221_0805_AllanVariance(:,5);
    LT6221_0805_AllanVariance_PDET_amp = LT6221_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6221_0805_AllanVariance_Vd_f = LT6221_0805_AllanVariance(:,11);
    LT6221_0805_AllanVariance_Vd_amp = LT6221_0805_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6221_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0805_DC = readmatrix('LT6221/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    LT6221_0805_DC_current_f = LT6221_0805_DC(:,1);
    LT6221_0805_DC_current_amp = LT6221_0805_DC(:,2);

    %Power Detector
    LT6221_0805_DC_PDET_f = LT6221_0805_DC(:,3);
    LT6221_0805_DC_PDET_amp = (2.856/2.69)*LT6221_0805_DC(:,4);

    %Vd
    LT6221_0805_DC_Vd_f = LT6221_0805_DC(:,15);
    LT6221_0805_DC_vd_amp = (2/0.891)*LT6221_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6221_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_0805_history = readmatrix('LT6221/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    LT6221_0805_history_current_f = LT6221_0805_history(:,1);
    LT6221_0805_history_current_amp = LT6221_0805_history(:,2);

    %Power Detector
    LT6221_0805_history_PDET_f = LT6221_0805_history(:,3);
    LT6221_0805_history_PDET_amp = (2.856/2.69)*LT6221_0805_history(:,4);

    %Vd
    LT6221_0805_history_Vd_f = LT6221_0805_history(:,15);  
    LT6221_0805_history_Vd_amp = (2/0.916)*LT6221_0805_history(:,16);
end

for LT6221_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_1206_AllanVariance = readmatrix('LT6221/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    LT6221_1206_AllanVariance_current_f = LT6221_1206_AllanVariance(:,3);
    LT6221_1206_AllanVariance_current_amp = LT6221_1206_AllanVariance(:,4);

    %Power Detector
    LT6221_1206_AllanVariance_PDET_f = LT6221_1206_AllanVariance(:,5);
    LT6221_1206_AllanVariance_PDET_amp = LT6221_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6221_1206_AllanVariance_Vd_f = LT6221_1206_AllanVariance(:,11);
    LT6221_1206_AllanVariance_Vd_amp = LT6221_1206_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6221_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_1206_DC = readmatrix('LT6221/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    LT6221_1206_DC_current_f = LT6221_1206_DC(:,1);
    LT6221_1206_DC_current_amp = LT6221_1206_DC(:,2);

    %Power Detector
    LT6221_1206_DC_PDET_f = LT6221_1206_DC(:,3);
    LT6221_1206_DC_PDET_amp = (2.856/2.69)*LT6221_1206_DC(:,4);

    %Vd
    LT6221_1206_DC_Vd_f = LT6221_1206_DC(:,15);
    LT6221_1206_DC_vd_amp = (2/0.891)*LT6221_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6221_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6221 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6221_1206_history = readmatrix('LT6221/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    LT6221_1206_history_current_f = LT6221_1206_history(:,1);
    LT6221_1206_history_current_amp = LT6221_1206_history(:,2);

    %Power Detector
    LT6221_1206_history_PDET_f = LT6221_1206_history(:,3);
    LT6221_1206_history_PDET_amp = (2.856/2.69)*LT6221_1206_history(:,4);

    %Vd
    LT6221_1206_history_Vd_f = LT6221_1206_history(:,15);  
    LT6221_1206_history_Vd_amp = (2/0.916)*LT6221_1206_history(:,16);
end





for LT6236_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0402_AllanVariance = readmatrix('LT6236/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    LT6236_0402_AllanVariance_current_f = LT6236_0402_AllanVariance(:,3);
    LT6236_0402_AllanVariance_current_amp = LT6236_0402_AllanVariance(:,4);

    %Power Detector
    LT6236_0402_AllanVariance_PDET_f = LT6236_0402_AllanVariance(:,5);
    LT6236_0402_AllanVariance_PDET_amp = LT6236_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6236_0402_AllanVariance_Vd_f = LT6236_0402_AllanVariance(:,11);
    LT6236_0402_AllanVariance_Vd_amp = LT6236_0402_AllanVariance(:,12) + 20*log10(2/0.891);
end

for LT6236_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0402_DC = readmatrix('LT6236/DC Level 0402.csv', 'Delimiter', ';');
    
    %Current
    LT6236_0402_DC_current_f = LT6236_0402_DC(:,1);
    LT6236_0402_DC_current_amp = LT6236_0402_DC(:,2);
    
    %Power Detector
    LT6236_0402_DC_PDET_f = LT6236_0402_DC(:,3);
    LT6236_0402_DC_PDET_amp = (2.856/2.69)*LT6236_0402_DC(:,4);
    
    %Vd
    LT6236_0402_DC_Vd_f = LT6236_0402_DC(:,15);
    LT6236_0402_DC_vd_amp = (2/0.891)*LT6236_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0402_history = readmatrix('LT6236/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    LT6236_0402_history_current_f = LT6236_0402_history(:,1);
    LT6236_0402_history_current_amp = LT6236_0402_history(:,2);

    %Power Detector
    LT6236_0402_history_PDET_f = LT6236_0402_history(:,3);
    LT6236_0402_history_PDET_amp = (2.856/2.69)*LT6236_0402_history(:,4);

    %Vd
    LT6236_0402_history_Vd_f = LT6236_0402_history(:,15);  
    LT6236_0402_history_Vd_amp = (2/0.916)*LT6236_0402_history(:,16);
end

for LT6236_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0805_AllanVariance = readmatrix('LT6236/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    LT6236_0805_AllanVariance_current_f = LT6236_0805_AllanVariance(:,3);
    LT6236_0805_AllanVariance_current_amp = LT6236_0805_AllanVariance(:,4);

    %Power Detector
    LT6236_0805_AllanVariance_PDET_f = LT6236_0805_AllanVariance(:,5);
    LT6236_0805_AllanVariance_PDET_amp = LT6236_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6236_0805_AllanVariance_Vd_f = LT6236_0805_AllanVariance(:,11);
    LT6236_0805_AllanVariance_Vd_amp = LT6236_0805_AllanVariance(:,12) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0805_DC = readmatrix('LT6236/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    LT6236_0805_DC_current_f = LT6236_0805_DC(:,1);
    LT6236_0805_DC_current_amp = LT6236_0805_DC(:,2);

    %Power Detector
    LT6236_0805_DC_PDET_f = LT6236_0805_DC(:,3);
    LT6236_0805_DC_PDET_amp = (2.856/2.69)*LT6236_0805_DC(:,4);

    %Vd
    LT6236_0805_DC_Vd_f = LT6236_0805_DC(:,15);
    LT6236_0805_DC_vd_amp = (2/0.891)*LT6236_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_0805_history = readmatrix('LT6236/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    LT6236_0805_history_current_f = LT6236_0805_history(:,1);
    LT6236_0805_history_current_amp = LT6236_0805_history(:,2);

    %Power Detector
    LT6236_0805_history_PDET_f = LT6236_0805_history(:,3);
    LT6236_0805_history_PDET_amp = (2.856/2.69)*LT6236_0805_history(:,4);

    %Vd
    LT6236_0805_history_Vd_f = LT6236_0805_history(:,15);  
    LT6236_0805_history_Vd_amp = (2/0.916)*LT6236_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_1206_AllanVariance = readmatrix('LT6236/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    LT6236_1206_AllanVariance_current_f = LT6236_1206_AllanVariance(:,3);
    LT6236_1206_AllanVariance_current_amp = LT6236_1206_AllanVariance(:,4);

    %Power Detector
    LT6236_1206_AllanVariance_PDET_f = LT6236_1206_AllanVariance(:,5);
    LT6236_1206_AllanVariance_PDET_amp = LT6236_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT6236_1206_AllanVariance_Vd_f = LT6236_1206_AllanVariance(:,17);
    LT6236_1206_AllanVariance_Vd_amp = LT6236_1206_AllanVariance(:,18) + 20*log10(2/0.891);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_1206_DC = readmatrix('LT6236/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    LT6236_1206_DC_current_f = LT6236_1206_DC(:,1);
    LT6236_1206_DC_current_amp = LT6236_1206_DC(:,2);

    %Power Detector
    LT6236_1206_DC_PDET_f = LT6236_1206_DC(:,3);
    LT6236_1206_DC_PDET_amp = (2.856/2.69)*LT6236_1206_DC(:,4);

    %Vd
    LT6236_1206_DC_Vd_f = LT6236_1206_DC(:,15);
    LT6236_1206_DC_vd_amp = (2/0.891)*LT6236_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT6236_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT6236 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT6236_1206_history = readmatrix('LT6236/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    LT6236_1206_history_current_f = LT6236_1206_history(:,1);
    LT6236_1206_history_current_amp = LT6236_1206_history(:,2);

    %Power Detector
    LT6236_1206_history_PDET_f = LT6236_1206_history(:,3);
    LT6236_1206_history_PDET_amp = (2.856/2.69)*LT6236_1206_history(:,4);

    %Vd
    LT6236_1206_history_Vd_f = LT6236_1206_history(:,15);  
    LT6236_1206_history_Vd_amp = (2/0.916)*LT6236_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%LDOs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for LT1763_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0402_AllanVariance = readmatrix('LT1763/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    LT1763_0402_AllanVariance_current_f = LT1763_0402_AllanVariance(:,3);
    LT1763_0402_AllanVariance_current_amp = LT1763_0402_AllanVariance(:,4);

    %Power Detector
    LT1763_0402_AllanVariance_PDET_f = LT1763_0402_AllanVariance(:,5);
    LT1763_0402_AllanVariance_PDET_amp = LT1763_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT1763_0402_AllanVariance_Vd_f = LT1763_0402_AllanVariance(:,17);
    LT1763_0402_AllanVariance_Vd_amp = LT1763_0402_AllanVariance(:,18) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0402_DC = readmatrix('LT1763/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    LT1763_0402_DC_current_f = LT1763_0402_DC(:,1);
    LT1763_0402_DC_current_amp = LT1763_0402_DC(:,2);

    %Power Detector
    LT1763_0402_DC_PDET_f = LT1763_0402_DC(:,3);
    LT1763_0402_DC_PDET_amp = (2.856/2.69)*LT1763_0402_DC(:,4);

    %Vd
    LT1763_0402_DC_Vd_f = LT1763_0402_DC(:,15);
    LT1763_0402_DC_vd_amp = (4.951/(2.19))*LT1763_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0402_history = readmatrix('LT1763/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    LT1763_0402_history_current_f = LT1763_0402_history(:,1);
    LT1763_0402_history_current_amp = LT1763_0402_history(:,2);

    %Power Detector
    LT1763_0402_history_PDET_f = LT1763_0402_history(:,3);
    LT1763_0402_history_PDET_amp = (2.856/2.69)*LT1763_0402_history(:,4);

    %Vd
    LT1763_0402_history_Vd_f = LT1763_0402_history(:,15);  
    LT1763_0402_history_Vd_amp = (4.951/(2.19))*LT1763_0402_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0805_AllanVariance = readmatrix('LT1763/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    LT1763_0805_AllanVariance_current_f = LT1763_0805_AllanVariance(:,3);
    LT1763_0805_AllanVariance_current_amp = LT1763_0805_AllanVariance(:,4);

    %Power Detector
    LT1763_0805_AllanVariance_PDET_f = LT1763_0805_AllanVariance(:,5);
    LT1763_0805_AllanVariance_PDET_amp = LT1763_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT1763_0805_AllanVariance_Vd_f = LT1763_0805_AllanVariance(:,11);
    LT1763_0805_AllanVariance_Vd_amp = LT1763_0805_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0805_DC = readmatrix('LT1763/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    LT1763_0805_DC_current_f = LT1763_0805_DC(:,1);
    LT1763_0805_DC_current_amp = LT1763_0805_DC(:,2);

    %Power Detector
    LT1763_0805_DC_PDET_f = LT1763_0805_DC(:,3);
    LT1763_0805_DC_PDET_amp = (2.856/2.69)*LT1763_0805_DC(:,4);

    %Vd
    LT1763_0805_DC_Vd_f = LT1763_0805_DC(:,15);
    LT1763_0805_DC_vd_amp = (4.951/(2.19))*LT1763_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_0805_history = readmatrix('LT1763/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    LT1763_0805_history_current_f = LT1763_0805_history(:,1);
    LT1763_0805_history_current_amp = LT1763_0805_history(:,2);

    %Power Detector
    LT1763_0805_history_PDET_f = LT1763_0805_history(:,3);
    LT1763_0805_history_PDET_amp = (2.856/2.69)*LT1763_0805_history(:,4);

    %Vd
    LT1763_0805_history_Vd_f = LT1763_0805_history(:,15);  
    LT1763_0805_history_Vd_amp = (4.951/(2.19))*LT1763_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_1206_AllanVariance = readmatrix('LT1763/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    LT1763_1206_AllanVariance_current_f = LT1763_1206_AllanVariance(:,3);
    LT1763_1206_AllanVariance_current_amp = LT1763_1206_AllanVariance(:,4);

    %Power Detector
    LT1763_1206_AllanVariance_PDET_f = LT1763_1206_AllanVariance(:,5);
    LT1763_1206_AllanVariance_PDET_amp = LT1763_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    LT1763_1206_AllanVariance_Vd_f = LT1763_1206_AllanVariance(:,11);
    LT1763_1206_AllanVariance_Vd_amp = LT1763_1206_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_1206_DC = readmatrix('LT1763/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    LT1763_1206_DC_current_f = LT1763_1206_DC(:,1);
    LT1763_1206_DC_current_amp = LT1763_1206_DC(:,2);

    %Power Detector
    LT1763_1206_DC_PDET_f = LT1763_1206_DC(:,3);
    LT1763_1206_DC_PDET_amp = (2.856/2.69)*LT1763_1206_DC(:,4);

    %Vd
    LT1763_1206_DC_Vd_f = LT1763_1206_DC(:,15);
    LT1763_1206_DC_vd_amp = (4.951/(2.19))*LT1763_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for LT1763_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT1763 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    LT1763_1206_history = readmatrix('LT1763/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    LT1763_1206_history_current_f = LT1763_1206_history(:,1);
    LT1763_1206_history_current_amp = LT1763_1206_history(:,2);

    %Power Detector
    LT1763_1206_history_PDET_f = LT1763_1206_history(:,3);
    LT1763_1206_history_PDET_amp = (2.856/2.69)*LT1763_1206_history(:,4);

    %Vd
    LT1763_1206_history_Vd_f = LT1763_1206_history(:,15);  
    LT1763_1206_history_Vd_amp = (4.951/(2.19))*LT1763_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end




for NCP731_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0402_AllanVariance = readmatrix('NCP731/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    NCP731_0402_AllanVariance_current_f = NCP731_0402_AllanVariance(:,3);
    NCP731_0402_AllanVariance_current_amp = NCP731_0402_AllanVariance(:,4);

    %Power Detector
    NCP731_0402_AllanVariance_PDET_f = NCP731_0402_AllanVariance(:,5);
    NCP731_0402_AllanVariance_PDET_amp = NCP731_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    NCP731_0402_AllanVariance_Vd_f = NCP731_0402_AllanVariance(:,11);
    NCP731_0402_AllanVariance_Vd_amp = NCP731_0402_AllanVariance(:,12) + 20*log10(2.25);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0402_DC = readmatrix('NCP731/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    NCP731_0402_DC_current_f = NCP731_0402_DC(:,1);
    NCP731_0402_DC_current_amp = NCP731_0402_DC(:,2);

    %Power Detector
    NCP731_0402_DC_PDET_f = NCP731_0402_DC(:,3);
    NCP731_0402_DC_PDET_amp = (2.856/2.69)*NCP731_0402_DC(:,4);

    %Vd
    NCP731_0402_DC_Vd_f = NCP731_0402_DC(:,15);
    NCP731_0402_DC_vd_amp = (4.956/(2.2))*NCP731_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0402_history = readmatrix('NCP731/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    NCP731_0402_history_current_f = NCP731_0402_history(:,1);
    NCP731_0402_history_current_amp = NCP731_0402_history(:,2);

    %Power Detector
    NCP731_0402_history_PDET_f = NCP731_0402_history(:,3);
    NCP731_0402_history_PDET_amp = (2.856/2.69)*NCP731_0402_history(:,4);

    %Vd
    NCP731_0402_history_Vd_f = NCP731_0402_history(:,15);  
    NCP731_0402_history_Vd_amp = (4.956/(2.2))*NCP731_0402_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0805_AllanVariance = readmatrix('NCP731/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    NCP731_0805_AllanVariance_current_f = NCP731_0805_AllanVariance(:,3);
    NCP731_0805_AllanVariance_current_amp = NCP731_0805_AllanVariance(:,4);

    %Power Detector
    NCP731_0805_AllanVariance_PDET_f = NCP731_0805_AllanVariance(:,5);
    NCP731_0805_AllanVariance_PDET_amp = NCP731_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    NCP731_0805_AllanVariance_Vd_f = NCP731_0805_AllanVariance(:,11);
    NCP731_0805_AllanVariance_Vd_amp = NCP731_0805_AllanVariance(:,12) + 20*log10(2.25);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0805_DC = readmatrix('NCP731/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    NCP731_0805_DC_current_f = NCP731_0805_DC(:,1);
    NCP731_0805_DC_current_amp = NCP731_0805_DC(:,2);

    %Power Detector
    NCP731_0805_DC_PDET_f = NCP731_0805_DC(:,3);
    NCP731_0805_DC_PDET_amp = (2.856/2.69)*NCP731_0805_DC(:,4);

    %Vd
    NCP731_0805_DC_Vd_f = NCP731_0805_DC(:,15);
    NCP731_0805_DC_vd_amp = (4.956/(2.2))*NCP731_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_0805_history = readmatrix('NCP731/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    NCP731_0805_history_current_f = NCP731_0805_history(:,1);
    NCP731_0805_history_current_amp = NCP731_0805_history(:,2);

    %Power Detector
    NCP731_0805_history_PDET_f = NCP731_0805_history(:,3);
    NCP731_0805_history_PDET_amp = (2.856/2.69)*NCP731_0805_history(:,4);

    %Vd
    NCP731_0805_history_Vd_f = NCP731_0805_history(:,15);  
    NCP731_0805_history_Vd_amp = (4.956/(2.2))*NCP731_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_1206_AllanVariance = readmatrix('NCP731/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    NCP731_1206_AllanVariance_current_f = NCP731_1206_AllanVariance(:,3);
    NCP731_1206_AllanVariance_current_amp = NCP731_1206_AllanVariance(:,4);

    %Power Detector
    NCP731_1206_AllanVariance_PDET_f = NCP731_1206_AllanVariance(:,5);
    NCP731_1206_AllanVariance_PDET_amp = NCP731_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    NCP731_1206_AllanVariance_Vd_f = NCP731_1206_AllanVariance(:,11);
    NCP731_1206_AllanVariance_Vd_amp = NCP731_1206_AllanVariance(:,12) + 20*log10(2.25);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_1206_DC = readmatrix('NCP731/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    NCP731_1206_DC_current_f = NCP731_1206_DC(:,1);
    NCP731_1206_DC_current_amp = NCP731_1206_DC(:,2);

    %Power Detector
    NCP731_1206_DC_PDET_f = NCP731_1206_DC(:,3);
    NCP731_1206_DC_PDET_amp = (2.856/2.69)*NCP731_1206_DC(:,4);

    %Vd
    NCP731_1206_DC_Vd_f = NCP731_1206_DC(:,15);
    NCP731_1206_DC_vd_amp = (4.956/(2.2))*NCP731_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for NCP731_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %NCP731 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    NCP731_1206_history = readmatrix('NCP731/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    NCP731_1206_history_current_f = NCP731_1206_history(:,1);
    NCP731_1206_history_current_amp = NCP731_1206_history(:,2);

    %Power Detector
    NCP731_1206_history_PDET_f = NCP731_1206_history(:,3);
    NCP731_1206_history_PDET_amp = (2.856/2.69)*NCP731_1206_history(:,4);

    %Vd
    NCP731_1206_history_Vd_f = NCP731_1206_history(:,15);  
    NCP731_1206_history_Vd_amp = (4.956/(2.2))*NCP731_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end






for sLT3045_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0402_AllanVariance = readmatrix('Single LT3045/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    sLT3045_0402_AllanVariance_current_f = sLT3045_0402_AllanVariance(:,3);
    sLT3045_0402_AllanVariance_current_amp = sLT3045_0402_AllanVariance(:,4);

    %Power Detector
    sLT3045_0402_AllanVariance_PDET_f = sLT3045_0402_AllanVariance(:,5);
    sLT3045_0402_AllanVariance_PDET_amp = sLT3045_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    sLT3045_0402_AllanVariance_Vd_f = sLT3045_0402_AllanVariance(:,11);
    sLT3045_0402_AllanVariance_Vd_amp = sLT3045_0402_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0402_DC = readmatrix('Single LT3045/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    sLT3045_0402_DC_current_f = sLT3045_0402_DC(:,1);
    sLT3045_0402_DC_current_amp = sLT3045_0402_DC(:,2);

    %Power Detector
    sLT3045_0402_DC_PDET_f = sLT3045_0402_DC(:,3);
    sLT3045_0402_DC_PDET_amp = (2.856/2.69)*sLT3045_0402_DC(:,4);

    %Vd
    sLT3045_0402_DC_Vd_f = sLT3045_0402_DC(:,15);
    sLT3045_0402_DC_vd_amp = (4.975/(2.20))*sLT3045_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0402_history = readmatrix('Single LT3045/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    sLT3045_0402_history_current_f = sLT3045_0402_history(:,1);
    sLT3045_0402_history_current_amp = sLT3045_0402_history(:,2);

    %Power Detector
    sLT3045_0402_history_PDET_f = sLT3045_0402_history(:,3);
    sLT3045_0402_history_PDET_amp = (2.856/2.69)*sLT3045_0402_history(:,4);

    %Vd
    sLT3045_0402_history_Vd_f = sLT3045_0402_history(:,15);  
    sLT3045_0402_history_Vd_amp = (4.975/(2.20))*sLT3045_0402_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0805_AllanVariance = readmatrix('Single LT3045/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    sLT3045_0805_AllanVariance_current_f = sLT3045_0805_AllanVariance(:,3);
    sLT3045_0805_AllanVariance_current_amp = sLT3045_0805_AllanVariance(:,4);

    %Power Detector
    sLT3045_0805_AllanVariance_PDET_f = sLT3045_0805_AllanVariance(:,5);
    sLT3045_0805_AllanVariance_PDET_amp = sLT3045_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    sLT3045_0805_AllanVariance_Vd_f = sLT3045_0805_AllanVariance(:,11);
    sLT3045_0805_AllanVariance_Vd_amp = sLT3045_0805_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0805_DC = readmatrix('Single LT3045/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    sLT3045_0805_DC_current_f = sLT3045_0805_DC(:,1);
    sLT3045_0805_DC_current_amp = sLT3045_0805_DC(:,2);

    %Power Detector
    sLT3045_0805_DC_PDET_f = sLT3045_0805_DC(:,3);
    sLT3045_0805_DC_PDET_amp = (2.856/2.69)*sLT3045_0805_DC(:,4);

    %Vd
    sLT3045_0805_DC_Vd_f = sLT3045_0805_DC(:,15);
    sLT3045_0805_DC_vd_amp = (4.975/(2.20))*sLT3045_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_0805_history = readmatrix('Single LT3045/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    sLT3045_0805_history_current_f = sLT3045_0805_history(:,1);
    sLT3045_0805_history_current_amp = sLT3045_0805_history(:,2);

    %Power Detector
    sLT3045_0805_history_PDET_f = sLT3045_0805_history(:,3);
    sLT3045_0805_history_PDET_amp = (2.856/2.69)*sLT3045_0805_history(:,4);

    %Vd
    sLT3045_0805_history_Vd_f = sLT3045_0805_history(:,15);  
    sLT3045_0805_history_Vd_amp = (4.975/(2.20))*sLT3045_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_1206_AllanVariance = readmatrix('Single LT3045/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    sLT3045_1206_AllanVariance_current_f = sLT3045_1206_AllanVariance(:,3);
    sLT3045_1206_AllanVariance_current_amp = sLT3045_1206_AllanVariance(:,4);

    %Power Detector
    sLT3045_1206_AllanVariance_PDET_f = sLT3045_1206_AllanVariance(:,5);
    sLT3045_1206_AllanVariance_PDET_amp = sLT3045_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    sLT3045_1206_AllanVariance_Vd_f = sLT3045_1206_AllanVariance(:,11);
    sLT3045_1206_AllanVariance_Vd_amp = sLT3045_1206_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_1206_DC = readmatrix('Single LT3045/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    sLT3045_1206_DC_current_f = sLT3045_1206_DC(:,1);
    sLT3045_1206_DC_current_amp = sLT3045_1206_DC(:,2);

    %Power Detector
    sLT3045_1206_DC_PDET_f = sLT3045_1206_DC(:,3);
    sLT3045_1206_DC_PDET_amp = (2.856/2.69)*sLT3045_1206_DC(:,4);

    %Vd
    sLT3045_1206_DC_Vd_f = sLT3045_1206_DC(:,15);
    sLT3045_1206_DC_vd_amp = (4.975/(2.20))*sLT3045_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for sLT3045_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    sLT3045_1206_history = readmatrix('Single LT3045/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    sLT3045_1206_history_current_f = sLT3045_1206_history(:,1);
    sLT3045_1206_history_current_amp = sLT3045_1206_history(:,2);

    %Power Detector
    sLT3045_1206_history_PDET_f = sLT3045_1206_history(:,3);
    sLT3045_1206_history_PDET_amp = (2.856/2.69)*sLT3045_1206_history(:,4);

    %Vd
    sLT3045_1206_history_Vd_f = sLT3045_1206_history(:,15);  
    sLT3045_1206_history_Vd_amp = (4.975/(2.20))*sLT3045_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end







for pLT3045_0402_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0402_AllanVariance = readmatrix('Parallel LT3045/Allan Variance 0402.csv', 'Delimiter', ';');

    %Current
    pLT3045_0402_AllanVariance_current_f = pLT3045_0402_AllanVariance(:,3);
    pLT3045_0402_AllanVariance_current_amp = pLT3045_0402_AllanVariance(:,4);

    %Power Detector
    pLT3045_0402_AllanVariance_PDET_f = pLT3045_0402_AllanVariance(:,5);
    pLT3045_0402_AllanVariance_PDET_amp = pLT3045_0402_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    pLT3045_0402_AllanVariance_Vd_f = pLT3045_0402_AllanVariance(:,17);
    pLT3045_0402_AllanVariance_Vd_amp = pLT3045_0402_AllanVariance(:,18) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_0402_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0402_DC = readmatrix('Parallel LT3045/DC Level 0402.csv', 'Delimiter', ';');

    %Current
    pLT3045_0402_DC_current_f = pLT3045_0402_DC(:,1);
    pLT3045_0402_DC_current_amp = pLT3045_0402_DC(:,2);

    %Power Detector
    pLT3045_0402_DC_PDET_f = pLT3045_0402_DC(:,3);
    pLT3045_0402_DC_PDET_amp = (2.856/2.69)*pLT3045_0402_DC(:,4);

    %Vd
    pLT3045_0402_DC_Vd_f = pLT3045_0402_DC(:,15);
    pLT3045_0402_DC_vd_amp = (4.965/(2.196))*pLT3045_0402_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_0402_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0402 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0402_history = readmatrix('Parallel LT3045/Mean History 0402.csv', 'Delimiter', ';');

    %Current
    pLT3045_0402_history_current_f = pLT3045_0402_history(:,1);
    pLT3045_0402_history_current_amp = pLT3045_0402_history(:,2);

    %Power Detector
    pLT3045_0402_history_PDET_f = pLT3045_0402_history(:,3);
    pLT3045_0402_history_PDET_amp = (2.856/2.69)*pLT3045_0402_history(:,4);

    %Vd
    pLT3045_0402_history_Vd_f = pLT3045_0402_history(:,15);  
    pLT3045_0402_history_Vd_amp = (4.965/(2.196))*pLT3045_0402_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_0805_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0805_AllanVariance = readmatrix('Parallel LT3045/Allan Variance 0805.csv', 'Delimiter', ';');

    %Current
    pLT3045_0805_AllanVariance_current_f = pLT3045_0805_AllanVariance(:,3);
    pLT3045_0805_AllanVariance_current_amp = pLT3045_0805_AllanVariance(:,4);

    %Power Detector
    pLT3045_0805_AllanVariance_PDET_f = pLT3045_0805_AllanVariance(:,5);
    pLT3045_0805_AllanVariance_PDET_amp = pLT3045_0805_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    pLT3045_0805_AllanVariance_Vd_f = pLT3045_0805_AllanVariance(:,11);
    pLT3045_0805_AllanVariance_Vd_amp = pLT3045_0805_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_0805_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0805_DC = readmatrix('Parallel LT3045/DC Level 0805.csv', 'Delimiter', ';');

    %Current
    pLT3045_0805_DC_current_f = pLT3045_0805_DC(:,1);
    pLT3045_0805_DC_current_amp = pLT3045_0805_DC(:,2);

    %Power Detector
    pLT3045_0805_DC_PDET_f = pLT3045_0805_DC(:,3);
    pLT3045_0805_DC_PDET_amp = (2.856/2.69)*pLT3045_0805_DC(:,4);

    %Vd
    pLT3045_0805_DC_Vd_f = pLT3045_0805_DC(:,15);
    pLT3045_0805_DC_vd_amp = (4.965/(2.196))*pLT3045_0805_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_0805_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 0805 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_0805_history = readmatrix('Parallel LT3045/Mean History 0805.csv', 'Delimiter', ';');

    %Current
    pLT3045_0805_history_current_f = pLT3045_0805_history(:,1);
    pLT3045_0805_history_current_amp = pLT3045_0805_history(:,2);

    %Power Detector
    pLT3045_0805_history_PDET_f = pLT3045_0805_history(:,3);
    pLT3045_0805_history_PDET_amp = (2.856/2.69)*pLT3045_0805_history(:,4);

    %Vd
    pLT3045_0805_history_Vd_f = pLT3045_0805_history(:,15);  
    pLT3045_0805_history_Vd_amp = (4.965/(2.196))*pLT3045_0805_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_1206_Avar = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 allan variance
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_1206_AllanVariance = readmatrix('Parallel LT3045/Allan Variance 1206.csv', 'Delimiter', ';');

    %Current
    pLT3045_1206_AllanVariance_current_f = pLT3045_1206_AllanVariance(:,3);
    pLT3045_1206_AllanVariance_current_amp = pLT3045_1206_AllanVariance(:,4);

    %Power Detector
    pLT3045_1206_AllanVariance_PDET_f = pLT3045_1206_AllanVariance(:,5);
    pLT3045_1206_AllanVariance_PDET_amp = pLT3045_1206_AllanVariance(:,6) + 20*log10(2.859/2.7);

    %Vd
    pLT3045_1206_AllanVariance_Vd_f = pLT3045_1206_AllanVariance(:,11);
    pLT3045_1206_AllanVariance_Vd_amp = pLT3045_1206_AllanVariance(:,12) + 20*log10(2.26);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_1206_DClevel = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 dc level
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_1206_DC = readmatrix('Parallel LT3045/DC Level 1206.csv', 'Delimiter', ';');

    %Current
    pLT3045_1206_DC_current_f = pLT3045_1206_DC(:,1);
    pLT3045_1206_DC_current_amp = pLT3045_1206_DC(:,2);

    %Power Detector
    pLT3045_1206_DC_PDET_f = pLT3045_1206_DC(:,3);
    pLT3045_1206_DC_PDET_amp = (2.856/2.69)*pLT3045_1206_DC(:,4);

    %Vd
    pLT3045_1206_DC_Vd_f = pLT3045_1206_DC(:,15);
    pLT3045_1206_DC_vd_amp = (4.965/(2.196))*pLT3045_1206_DC(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end

for pLT3045_1206_mean_history = 1
    %%%%%%%%%%%%%%%%%%%%%%%%
    %LT3045 1206 mean history
    %%%%%%%%%%%%%%%%%%%%%%%%
    pLT3045_1206_history = readmatrix('Parallel LT3045/Mean History 1206.csv', 'Delimiter', ';');

    %Current
    pLT3045_1206_history_current_f = pLT3045_1206_history(:,1);
    pLT3045_1206_history_current_amp = pLT3045_1206_history(:,2);

    %Power Detector
    pLT3045_1206_history_PDET_f = pLT3045_1206_history(:,3);
    pLT3045_1206_history_PDET_amp = (2.856/2.69)*pLT3045_1206_history(:,4);

    %Vd
    pLT3045_1206_history_Vd_f = pLT3045_1206_history(:,15);  
    pLT3045_1206_history_Vd_amp = (4.965/(2.196))*pLT3045_1206_history(:,16);
    %%%%%%%%%%%%%%%%%%%%%%%%
end



NG_Avar = readmatrix('Noise Generator/Allan Variance LT6221 1206 no MMIC.csv', 'Delimiter', ';');
NG_DC = readmatrix('Noise Generator/DC Level LT6221 1206 no MMIC.csv', 'Delimiter', ';');
NG_mean = readmatrix('Noise Generator/Mean History LT6221 1206 no MMIC.csv', 'Delimiter', ';');
PWR__toAMp_mean = readmatrix('PWR supply to amp/Allan Varience.csv', 'Delimiter', ';');
SSAvar = readmatrix('S+vsS-/Allan Varience S+ to S-.csv', 'Delimiter', ';');
SSmean = readmatrix('S+vsS-/history mean for S+ to S-.csv', 'Delimiter', ';');
First_Extra = readmatrix('ExtraRuns LT6221/First/Mean History LT6221 1206.csv', 'Delimiter', ';');
Second_Extra = readmatrix('ExtraRuns LT6221/Second/Mean History LT6221 1206.csv', 'Delimiter', ';');
First_Extra_LDO = readmatrix('ExtraRuns NCP731/First/Mean History NCP731 1206.csv', 'Delimiter', ';');
Second_Extra_LDO = readmatrix('ExtraRuns NCP731/Second/Mean History NCP731 1206.csv', 'Delimiter', ';');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
target = [0.02, 0.5, 1, 5, 10, 80.87]; %Chosen Frequencies
arr_f1 = sLT3045_0805_history_Vd_f; %Chosen array in frequency
arr_amp = sLT3045_0805_history_Vd_amp; %Chosen array in amplitude

first = arr_amp(1)*10^9;
last = arr_amp(length(arr_amp))*10^9;

for i = 1:6
    [~, idx] = min(abs(arr_f1 - target(i)));
    closestValue = arr_f1(idx);
    arr_amp1 = arr_amp(idx);
    
    if(closestValue > target(i))
        arr_f2 = arr_f1(idx - 1);
        arr_amp2 = arr_amp(idx - 1);
    else
        arr_f2 = arr_f1(idx + 1);
        arr_amp2 = arr_amp(idx + 1);
    end
    
    
    f = [closestValue, arr_f2];
    A = [arr_amp1, arr_amp2];
    
    
    %Approximating amplitude at specific frequencies
    %Multiplies with 10^9 so we get it in nV
    Middle = interp1(f, A, target(i))*10^9 %Interpolation
end 

%RMS noise over spectrum graph
rms_noise = rms(arr_amp - mean(arr_amp))*10^9

%DC level
Vd_DC = mean(sLT3045_1206_DC_vd_amp);
Id_DC = mean(sLT3045_1206_DC_current_amp)/(21.7*0.47);
PDET_DC = mean(sLT3045_1206_DC_PDET_amp);


%Find corner frequency (fc)
PSD = arr_amp;
f   = arr_f1;

% Remove invalid values
valid = f > 0 & PSD > 0;
f = f(valid);
PSD = PSD(valid);

% Smooth the spectrum in log domain
PSD_smooth = smoothdata(PSD,'movmean',15);

% Calculate log-log slope
slope = diff(log10(PSD_smooth)) ./ diff(log10(f));

% Smooth the slope too
slope_smooth = smoothdata(slope,'movmean',15);

% Ignore very low frequencies, for example below 0.1 Hz
startIdx = find(f(1:end-1) > 0.1, 1, 'first');

% Need 5 consecutive points above threshold so we won't accidentally find a
% random point that is above -0.5
%The condition is -0.5 because flicker noise is -1, and white noise is 0. 
%-0.5 is in the middle of flicker and white
N = 5;
condition = slope_smooth(startIdx:end) > -0.5;

idx_end_rel = find(movsum(condition, N) == N, 1, 'first');

idx_rel = idx_end_rel - N + 1;
idx = startIdx + idx_rel - 1;

fc = f(idx)
fc_amp1 = PSD(idx)*10^9 %10^9 so we get it in nV
%semilogx(f(idx), PSD(idx), 'ro')
figure(2)
semilogx(f(idx), PSD(idx), 'ro')
hold on
semilogx(f, PSD, 'blue')
semilogx(f, PSD_smooth, 'green')
hold off
%yticks(0:0.05*10^-5:1.8*10^-5)



%Optimum integration time
tau = NCP731_0402_AllanVariance_Vd_f;
avar_dB = NCP731_0402_AllanVariance_Vd_amp;

valid = tau > 0 & isfinite(avar_dB);
tau = tau(valid);
avar_dB = avar_dB(valid);

avar_smooth = smoothdata(avar_dB, 'movmedian', 5);

slope = diff(avar_smooth) ./ diff(log10(tau));
slope_smooth = smoothdata(slope, 'movmean', 5);

%Accepts as flat if 3 data points that is smaller than 2dB/decade is found
threshold = 1;  % 1 dB per decade
N = 1; %1 data consecutive points must be found 

condition = abs(slope_smooth) < threshold;

idx_end = find(movsum(condition,N) == N, 1, 'first');
idx_start = idx_end - N + 1;

tau_flicker_start = tau(idx_start)
avar_flicker_start = avar_smooth(idx_start);


%When drift starts to dominate
% Find Allan minimum
[avar_min, idx_min] = min(avar_smooth);



% Start drift search AFTER the minimum, not exactly at it
offset = 5;   % skip 3 points after the minimum
startDriftIdx = idx_min + offset;

% Make sure index is valid
startDriftIdx = min(startDriftIdx, length(slope_smooth));

% Drift condition
threshold_up = 1;   % dB/decade
N = 1;              % consecutive points
%Protection so the stability region isn't just dependant on the slope. 
% But also if the drift has increased to more than 5dB form the minimum point
rise_limit = 1;
%offset = 10;

% Match AVAR values to slope values
avar_for_slope = avar_smooth(2:end);

% Full condition first
condition_full = (slope_smooth > threshold_up) & ...
                 (avar_for_slope > avar_min + rise_limit);

% Then start searching after minimum + offset
condition_up = condition_full(startDriftIdx:end);

idx_end_up_rel = find(movsum(condition_up,N) == N, 1, 'first');

if isempty(idx_end_up_rel)
    %disp('No increasing drift region found.');
    tau_drift_start = NaN;
    avar_drift_start = NaN;
else
    idx_end_up = startDriftIdx + idx_end_up_rel - 1;
    idx_start_up = idx_end_up - N + 1;

    tau_drift_start = tau(idx_start_up-1)
    avar_drift_start = avar_dB(idx_start_up-1);
end 

figure(4);
smooth = semilogx(tau, avar_smooth);
hold on
true = semilogx(tau, avar_dB);
plot(tau(idx_start), avar_dB(idx_start), 'ro')
plot(tau(idx_start), avar_smooth(idx_start), 'ro')
plot(tau(idx_start_up-1), avar_dB(idx_start_up-1), 'ro')
plot(tau(idx_start_up-1), avar_smooth(idx_start_up-1), 'ro')
slope(idx_start);
slope(idx_start_up);
hold off
legend([smooth, true], 'smooth', 'true');
ylim([-145 -60])
grid on


%Avar plots for all Vd
figure(5)
p1 = semilogx(LT6220_0402_AllanVariance_Vd_f, LT6220_0402_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', '-');
hold on
p2 = semilogx(LT6220_0805_AllanVariance_Vd_f, LT6220_0805_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', '--');
p3 = semilogx(LT6220_1206_AllanVariance_Vd_f, LT6220_1206_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', ':');

p4 = semilogx(LT6221_0402_AllanVariance_Vd_f, LT6221_0402_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', '-');
p5 = semilogx(LT6221_0805_AllanVariance_Vd_f, LT6221_0805_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', '--');
p6 = semilogx(LT6221_1206_AllanVariance_Vd_f, LT6221_1206_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', ':');

p7 = semilogx(LT6236_0402_AllanVariance_Vd_f, LT6236_0402_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', '-');
p8 = semilogx(LT6236_0805_AllanVariance_Vd_f, LT6236_0805_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', '--');
p9 = semilogx(LT6236_1206_AllanVariance_Vd_f, LT6236_1206_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', ':');

p10 = semilogx(LT6238_0402_AllanVariance_Vd_f, LT6238_0402_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', '-');
p11 = semilogx(LT6238_0805_AllanVariance_Vd_f, LT6238_0805_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', '--');
p12 = semilogx(LT6238_1206_AllanVariance_Vd_f, LT6238_1206_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', ':');

p13 = semilogx(ADA4805_0402_AllanVariance_Vd_f, ADA4805_0402_AllanVariance_Vd_amp, 'Color', 'k', 'Linestyle', '-');
p14 = semilogx(ADA4805_0805_AllanVariance_Vd_f, ADA4805_0805_AllanVariance_Vd_amp, 'Color', 'k', 'Linestyle', '--');
p15 = semilogx(ADA4805_1206_AllanVariance_Vd_f, ADA4805_1206_AllanVariance_Vd_amp, 'Color', 'k', 'Linestyle', ':');
hold off

legend([p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15], 'LT6220 0402', 'LT6220 0805', 'LT6220 1206', ...
    'LT6221 0402', 'LT6221 0805', 'LT6221 1206', 'LT6236 0402', 'LT6236 0805', 'LT6236 1206' ,'LT6238 0402', 'LT6238 0805', ...
    'LT6238 1206', 'ADA4805 0402', 'ADA4805 0805', 'ADA4805 1206')
xlabel('Time')
ylabel('Amplitude')
title('Allan variance of Vd for all OP Amps and their pad sizes')
grid on


%Avar plot for all LDO
figure(6)
p1_LDO = semilogx(LT1763_0402_AllanVariance_Vd_f, LT1763_0402_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', '-');
hold on
p2_LDO = semilogx(LT1763_0805_AllanVariance_Vd_f, LT1763_0805_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', '--');
p3_LDO = semilogx(LT1763_1206_AllanVariance_Vd_f, LT1763_1206_AllanVariance_Vd_amp, 'Color', 'r', 'Linestyle', ':');

p4_LDO = semilogx(NCP731_0402_AllanVariance_Vd_f, NCP731_0402_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', '-');
p5_LDO = semilogx(NCP731_0805_AllanVariance_Vd_f, NCP731_0805_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', '--');
p6_LDO = semilogx(NCP731_1206_AllanVariance_Vd_f, NCP731_1206_AllanVariance_Vd_amp, 'Color', 'g', 'Linestyle', ':');

p7_LDO = semilogx(sLT3045_0402_AllanVariance_Vd_f, sLT3045_0402_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', '-');
p8_LDO = semilogx(sLT3045_0805_AllanVariance_Vd_f, sLT3045_0805_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', '--');
p9_LDO = semilogx(sLT3045_1206_AllanVariance_Vd_f, sLT3045_1206_AllanVariance_Vd_amp, 'Color', 'b', 'Linestyle', ':');

p10_LDO = semilogx(pLT3045_0402_AllanVariance_Vd_f, pLT3045_0402_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', '-');
p11_LDO = semilogx(pLT3045_0805_AllanVariance_Vd_f, pLT3045_0805_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', '--');
p12_LDO = semilogx(pLT3045_1206_AllanVariance_Vd_f, pLT3045_1206_AllanVariance_Vd_amp, 'Color', 'm', 'Linestyle', ':');
hold off

legend([p1_LDO, p2_LDO, p3_LDO, p4_LDO, p5_LDO, p6_LDO, p7_LDO, p8_LDO, p9_LDO, p10_LDO, p11_LDO, p12_LDO], 'LT1763 0402', 'LT1763 0805', 'LT1763 1206', ...
    'NCP731 0402', 'NCP731 0805', 'NCP731 1206', 'Single LT3045 0402', 'Single LT3045 0805', 'Single LT3045 1206' ,'Parallel LT3045 0402', 'Parallel LT3045 0805', ...
    'Parallel LT3045 1206')
xlabel('Time')
ylabel('Amplitude')
title('Allan variance of Vd for all LDOs and their pad sizes')
grid on

%PSD plot for all OPs
figure(7)
p1_PSD = semilogx(LT6220_0402_history_Vd_f, LT6220_0402_history_Vd_amp, 'Color', 'r', 'Linestyle', '-');
hold on
p2_PSD = semilogx(LT6220_0805_history_Vd_f, LT6220_0805_history_Vd_amp, 'Color', 'r', 'Linestyle', '--');
p3_PSD = semilogx(LT6220_1206_history_Vd_f, LT6220_1206_history_Vd_amp, 'Color', 'r', 'Linestyle', ':');

p4_PSD = semilogx(LT6221_0402_history_Vd_f, LT6221_0402_history_Vd_amp, 'Color', 'g', 'Linestyle', '-');
p5_PSD = semilogx(LT6221_0805_history_Vd_f, LT6221_0805_history_Vd_amp, 'Color', 'g', 'Linestyle', '--');
p6_PSD = semilogx(LT6221_1206_history_Vd_f, LT6221_1206_history_Vd_amp, 'Color', 'g', 'Linestyle', ':');

p7_PSD = semilogx(LT6236_0402_history_Vd_f, LT6236_0402_history_Vd_amp, 'Color', 'b', 'Linestyle', '-');
p8_PSD = semilogx(LT6236_0805_history_Vd_f, LT6236_0805_history_Vd_amp, 'Color', 'b', 'Linestyle', '--');
p9_PSD = semilogx(LT6236_1206_history_Vd_f, LT6236_1206_history_Vd_amp, 'Color', 'b', 'Linestyle', ':');

p10_PSD = semilogx(LT6238_0402_history_Vd_f, LT6238_0402_history_Vd_amp, 'Color', 'm', 'Linestyle', '-');
p11_PSD = semilogx(LT6238_0805_history_Vd_f, LT6238_0805_history_Vd_amp, 'Color', 'm', 'Linestyle', '--');
p12_PSD = semilogx(LT6238_1206_history_Vd_f, LT6238_1206_history_Vd_amp, 'Color', 'm', 'Linestyle', ':');

p13_PSD = semilogx(ADA4805_0402_history_Vd_f, ADA4805_0402_history_Vd_amp, 'Color', 'k', 'Linestyle', '-');
p14_PSD = semilogx(ADA4805_0805_history_Vd_f, ADA4805_0805_history_Vd_amp, 'Color', 'k', 'Linestyle', '--');
p15_PSD = semilogx(ADA4805_1206_history_Vd_f, ADA4805_1206_history_Vd_amp, 'Color', 'k', 'Linestyle', ':');
hold off

legend([p1_PSD, p2_PSD, p3_PSD, p4_PSD, p5_PSD, p6_PSD, p7_PSD, p8_PSD, p9_PSD, p10_PSD, p11_PSD, p12_PSD, p13_PSD, p14_PSD, p15_PSD], 'LT6220 0402', 'LT6220 0805', 'LT6220 1206', ...
    'LT6221 0402', 'LT6221 0805', 'LT6221 1206', 'LT6236 0402', 'LT6236 0805', 'LT6236 1206' ,'LT6238 0402', 'LT6238 0805', ...
    'LT6238 1206', 'ADA4805 0402', 'ADA4805 0805', 'ADA4805 1206')
xlabel('Frequency')
ylabel('Amplitude')
title('PSD of Vd for all OP Amps and their pad sizes')
yticks(0:0.1*10^-4:1.4*10^-4)
grid on




%PSD plot for all LDO
figure(8)
p1_LDO_PSD = semilogx(LT1763_0402_history_Vd_f, LT1763_0402_history_Vd_amp, 'Color', 'r', 'Linestyle', '-');
hold on
p2_LDO_PSD = semilogx(LT1763_0805_history_Vd_f, LT1763_0805_history_Vd_amp, 'Color', 'r', 'Linestyle', '--');
p3_LDO_PSD = semilogx(LT1763_1206_history_Vd_f, LT1763_1206_history_Vd_amp, 'Color', 'r', 'Linestyle', ':');

p4_LDO_PSD = semilogx(NCP731_0402_history_Vd_f, NCP731_0402_history_Vd_amp, 'Color', 'g', 'Linestyle', '-');
p5_LDO_PSD = semilogx(NCP731_0805_history_Vd_f, NCP731_0805_history_Vd_amp, 'Color', 'g', 'Linestyle', '--');
p6_LDO_PSD = semilogx(NCP731_1206_history_Vd_f, NCP731_1206_history_Vd_amp, 'Color', 'g', 'Linestyle', ':');

p7_LDO_PSD = semilogx(sLT3045_0402_history_Vd_f, sLT3045_0402_history_Vd_amp, 'Color', 'b', 'Linestyle', '-');
p8_LDO_PSD = semilogx(sLT3045_0805_history_Vd_f, sLT3045_0805_history_Vd_amp, 'Color', 'b', 'Linestyle', '--');
p9_LDO_PSD = semilogx(sLT3045_1206_history_Vd_f, sLT3045_1206_history_Vd_amp, 'Color', 'b', 'Linestyle', ':');

p10_LDO_PSD = semilogx(pLT3045_0402_history_Vd_f, pLT3045_0402_history_Vd_amp, 'Color', 'm', 'Linestyle', '-');
p11_LDO_PSD = semilogx(pLT3045_0805_history_Vd_f, pLT3045_0805_history_Vd_amp, 'Color', 'm', 'Linestyle', '--');
p12_LDO_PSD = semilogx(pLT3045_1206_history_Vd_f, pLT3045_1206_history_Vd_amp, 'Color', 'm', 'Linestyle', ':');
hold off

legend([p1_LDO_PSD, p2_LDO_PSD, p3_LDO_PSD, p4_LDO_PSD, p5_LDO_PSD, p6_LDO_PSD, p7_LDO_PSD, p8_LDO_PSD, p9_LDO_PSD, p10_LDO_PSD, p11_LDO_PSD, p12_LDO_PSD], 'LT1763 0402', 'LT1763 0805', 'LT1763 1206', ...
    'NCP731 0402', 'NCP731 0805', 'NCP731 1206', 'Single LT3045 0402', 'Single LT3045 0805', 'Single LT3045 1206' ,'Parallel LT3045 0402', 'Parallel LT3045 0805', ...
    'Parallel LT3045 1206')
xlabel('Frequency')
ylabel('Amplitude')
title('PSD of Vd for all LDOs and their pad sizes')
yticks(0:0.1*10^-5:1.4*10^-4)
grid on




%AVAR GND loop
figure(9)
semilogx(LT6221_0805_AllanVariance(:,7), LT6221_0805_AllanVariance(:,8));
xlabel('Time')
ylabel('Amplitude')
title('Allan variance of GND loop')
grid on



%PDET Mean OP Amp and LDO all
figure(10)
hold on;
grid on;

% Colors: one color per component group
OP1_color  = '#0072BD';  % LT6220
OP2_color  = '#D95319';  % LT6221
OP3_color  = '#EDB120';  % LT6236
OP4_color  = '#7E2F8E';  % LT6238
OP5_color  = '#77AC30';  % ADA4805

LDO1_color = '#4DBEEE';  % LT1763
LDO2_color = '#A2142F';  % NCP731
LDO3_color = '#000000';  % single LT3045
LDO4_color = '#808080';  % parallel LT3045

% Line styles: one style per resistor footprint
style_0402 = '-';
style_0805 = '--';
style_1206 = ':';

PDET_OP1_1 = semilogx(LT6220_0402_history_PDET_f, LT6220_0402_history_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_OP1_2 = semilogx(LT6220_0805_history_PDET_f, LT6220_0805_history_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_OP1_3 = semilogx(LT6220_1206_history_PDET_f, LT6220_1206_history_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_OP2_1 = semilogx(LT6221_0402_history_PDET_f, LT6221_0402_history_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_OP2_2 = semilogx(LT6221_0805_history_PDET_f, LT6221_0805_history_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_OP2_3 = semilogx(LT6221_1206_history_PDET_f, LT6221_1206_history_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_OP3_1 = semilogx(LT6236_0402_history_PDET_f, LT6236_0402_history_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_OP3_2 = semilogx(LT6236_0805_history_PDET_f, LT6236_0805_history_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_OP3_3 = semilogx(LT6236_1206_history_PDET_f, LT6236_1206_history_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_OP4_1 = semilogx(LT6238_0402_history_PDET_f, LT6238_0402_history_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_OP4_2 = semilogx(LT6238_0805_history_PDET_f, LT6238_0805_history_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_OP4_3 = semilogx(LT6238_1206_history_PDET_f, LT6238_1206_history_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_OP5_1 = semilogx(ADA4805_0402_history_PDET_f, ADA4805_0402_history_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_OP5_2 = semilogx(ADA4805_0805_history_PDET_f, ADA4805_0805_history_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_OP5_3 = semilogx(ADA4805_1206_history_PDET_f, ADA4805_1206_history_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_LDO1_1 = semilogx(LT1763_0402_history_PDET_f, LT1763_0402_history_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_LDO1_2 = semilogx(LT1763_0805_history_PDET_f, LT1763_0805_history_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_LDO1_3 = semilogx(LT1763_1206_history_PDET_f, LT1763_1206_history_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_LDO2_1 = semilogx(NCP731_0402_history_PDET_f, NCP731_0402_history_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_LDO2_2 = semilogx(NCP731_0805_history_PDET_f, NCP731_0805_history_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_LDO2_3 = semilogx(NCP731_1206_history_PDET_f, NCP731_1206_history_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_LDO3_1 = semilogx(sLT3045_0402_history_PDET_f, sLT3045_0402_history_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_LDO3_2 = semilogx(sLT3045_0805_history_PDET_f, sLT3045_0805_history_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_LDO3_3 = semilogx(sLT3045_1206_history_PDET_f, sLT3045_1206_history_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

PDET_LDO4_1 = semilogx(pLT3045_0402_history_PDET_f, pLT3045_0402_history_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
PDET_LDO4_2 = semilogx(pLT3045_0805_history_PDET_f, pLT3045_0805_history_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
PDET_LDO4_3 = semilogx(pLT3045_1206_history_PDET_f, pLT3045_1206_history_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

hold off
xlabel('Frequency')
ylabel('Amplitude')
title('PSD of PDET with all pad sizes on all OP Amps and LDOs')

legend([ ...
    PDET_OP1_1, PDET_OP1_2, PDET_OP1_3, ...
    PDET_OP2_1, PDET_OP2_2, PDET_OP2_3, ...
    PDET_OP3_1, PDET_OP3_2, PDET_OP3_3, ...
    PDET_OP4_1, PDET_OP4_2, PDET_OP4_3, ...
    PDET_OP5_1, PDET_OP5_2, PDET_OP5_3, ...
    PDET_LDO1_1, PDET_LDO1_2, PDET_LDO1_3, ...
    PDET_LDO2_1, PDET_LDO2_2, PDET_LDO2_3, ...
    PDET_LDO3_1, PDET_LDO3_2, PDET_LDO3_3, ...
    PDET_LDO4_1, PDET_LDO4_2, PDET_LDO4_3], ...
    { ...
    'LT6220 0402', 'LT6220 0805', 'LT6220 1206', ...
    'LT6221 0402', 'LT6221 0805', 'LT6221 1206', ...
    'LT6236 0402', 'LT6236 0805', 'LT6236 1206', ...
    'LT6238 0402', 'LT6238 0805', 'LT6238 1206', ...
    'ADA4805 0402', 'ADA4805 0805', 'ADA4805 1206', ...
    'LT1763 0402', 'LT1763 0805', 'LT1763 1206', ...
    'NCP731 0402', 'NCP731 0805', 'NCP731 1206', ...
    'sLT3045 0402', 'sLT3045 0805', 'sLT3045 1206', ...
    'pLT3045 0402', 'pLT3045 0805', 'pLT3045 1206'}, ...
    'Location', 'bestoutside');


%PDET AVAR OP AMP and LDO
figure(11)
hold on;
grid on;

% Colors: one color per component group
OP1_color  = '#0072BD';  % LT6220
OP2_color  = '#D95319';  % LT6221
OP3_color  = '#EDB120';  % LT6236
OP4_color  = '#7E2F8E';  % LT6238
OP5_color  = '#77AC30';  % ADA4805

LDO1_color = '#4DBEEE';  % LT1763
LDO2_color = '#A2142F';  % NCP731
LDO3_color = '#000000';  % single LT3045
LDO4_color = '#808080';  % parallel LT3045

% Line styles: one style per resistor footprint
style_0402 = '-';
style_0805 = '--';
style_1206 = ':';

Avar_PDET_OP1_1 = semilogx(LT6220_0402_AllanVariance_PDET_f, LT6220_0402_AllanVariance_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_OP1_2 = semilogx(LT6220_0805_AllanVariance_PDET_f, LT6220_0805_AllanVariance_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_OP1_3 = semilogx(LT6220_1206_AllanVariance_PDET_f, LT6220_1206_AllanVariance_PDET_amp, ...
    'Color', OP1_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_OP2_1 = semilogx(LT6221_0402_AllanVariance_PDET_f, LT6221_0402_AllanVariance_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_OP2_2 = semilogx(LT6221_0805_AllanVariance_PDET_f, LT6221_0805_AllanVariance_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_OP2_3 = semilogx(LT6221_1206_AllanVariance_PDET_f, LT6221_1206_AllanVariance_PDET_amp, ...
    'Color', OP2_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_OP3_1 = semilogx(LT6236_0402_AllanVariance_PDET_f, LT6236_0402_AllanVariance_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_OP3_2 = semilogx(LT6236_0805_AllanVariance_PDET_f, LT6236_0805_AllanVariance_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_OP3_3 = semilogx(LT6236_1206_AllanVariance_PDET_f, LT6236_1206_AllanVariance_PDET_amp, ...
    'Color', OP3_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_OP4_1 = semilogx(LT6238_0402_AllanVariance_PDET_f, LT6238_0402_AllanVariance_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_OP4_2 = semilogx(LT6238_0805_AllanVariance_PDET_f, LT6238_0805_AllanVariance_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_OP4_3 = semilogx(LT6238_1206_AllanVariance_PDET_f, LT6238_1206_AllanVariance_PDET_amp, ...
    'Color', OP4_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_OP5_1 = semilogx(ADA4805_0402_AllanVariance_PDET_f, ADA4805_0402_AllanVariance_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_OP5_2 = semilogx(ADA4805_0805_AllanVariance_PDET_f, ADA4805_0805_AllanVariance_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_OP5_3 = semilogx(ADA4805_1206_AllanVariance_PDET_f, ADA4805_1206_AllanVariance_PDET_amp, ...
    'Color', OP5_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_LDO1_1 = semilogx(LT1763_0402_AllanVariance_PDET_f, LT1763_0402_AllanVariance_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_LDO1_2 = semilogx(LT1763_0805_AllanVariance_PDET_f, LT1763_0805_AllanVariance_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_LDO1_3 = semilogx(LT1763_1206_AllanVariance_PDET_f, LT1763_1206_AllanVariance_PDET_amp, ...
    'Color', LDO1_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_LDO2_1 = semilogx(NCP731_0402_AllanVariance_PDET_f, NCP731_0402_AllanVariance_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_LDO2_2 = semilogx(NCP731_0805_AllanVariance_PDET_f, NCP731_0805_AllanVariance_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_LDO2_3 = semilogx(NCP731_1206_AllanVariance_PDET_f, NCP731_1206_AllanVariance_PDET_amp, ...
    'Color', LDO2_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_LDO3_1 = semilogx(sLT3045_0402_AllanVariance_PDET_f, sLT3045_0402_AllanVariance_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_LDO3_2 = semilogx(sLT3045_0805_AllanVariance_PDET_f, sLT3045_0805_AllanVariance_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_LDO3_3 = semilogx(sLT3045_1206_AllanVariance_PDET_f, sLT3045_1206_AllanVariance_PDET_amp, ...
    'Color', LDO3_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

Avar_PDET_LDO4_1 = semilogx(pLT3045_0402_AllanVariance_PDET_f, pLT3045_0402_AllanVariance_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_0402, 'LineWidth', 1.5);
Avar_PDET_LDO4_2 = semilogx(pLT3045_0805_AllanVariance_PDET_f, pLT3045_0805_AllanVariance_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_0805, 'LineWidth', 1.5);
Avar_PDET_LDO4_3 = semilogx(pLT3045_1206_AllanVariance_PDET_f, pLT3045_1206_AllanVariance_PDET_amp, ...
    'Color', LDO4_color, 'LineStyle', style_1206, 'LineWidth', 1.5);

hold off
grid on
xlabel('Time')
ylabel('Amplitude')
title('Allan variance of PDET with all pad sizes on all OP Amps and LDOs')

legend([ ...
    Avar_PDET_OP1_1, Avar_PDET_OP1_2, Avar_PDET_OP1_3, ...
    Avar_PDET_OP2_1, Avar_PDET_OP2_2, Avar_PDET_OP2_3, ...
    Avar_PDET_OP3_1, Avar_PDET_OP3_2, Avar_PDET_OP3_3, ...
    Avar_PDET_OP4_1, Avar_PDET_OP4_2, Avar_PDET_OP4_3, ...
    Avar_PDET_OP5_1, Avar_PDET_OP5_2, Avar_PDET_OP5_3, ...
    Avar_PDET_LDO1_1, Avar_PDET_LDO1_2, Avar_PDET_LDO1_3, ...
    Avar_PDET_LDO2_1, Avar_PDET_LDO2_2, Avar_PDET_LDO2_3, ...
    Avar_PDET_LDO3_1, Avar_PDET_LDO3_2, Avar_PDET_LDO3_3, ...
    Avar_PDET_LDO4_1, Avar_PDET_LDO4_2, Avar_PDET_LDO4_3], ...
    { ...
    'LT6220 0402', 'LT6220 0805', 'LT6220 1206', ...
    'LT6221 0402', 'LT6221 0805', 'LT6221 1206', ...
    'LT6236 0402', 'LT6236 0805', 'LT6236 1206', ...
    'LT6238 0402', 'LT6238 0805', 'LT6238 1206', ...
    'ADA4805 0402', 'ADA4805 0805', 'ADA4805 1206', ...
    'LT1763 0402', 'LT1763 0805', 'LT1763 1206', ...
    'NCP731 0402', 'NCP731 0805', 'NCP731 1206', ...
    'sLT3045 0402', 'sLT3045 0805', 'sLT3045 1206', ...
    'pLT3045 0402', 'pLT3045 0805', 'pLT3045 1206'}, ...
    'Location', 'bestoutside');