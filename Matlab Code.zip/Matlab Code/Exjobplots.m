%%%%%%%%%%%%%%%%%%%%%%%%
%vcc
%%%%%%%%%%%%%%%%%%%%%%%%
VCCdata = readmatrix('VCC1.csv', 'Delimiter', ';');

VCCfrequency = VCCdata(:,1);
VCCamplitude = VCCdata(:,2);


figure(1);
semilogx(VCCfrequency, VCCamplitude)
grid on
title('VCC')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
yticks(0:0.2*10^-7:7*10^-7)

hold on
plot(50, 350e-9, 'ro', 'MarkerSize', 10, 'LineWidth', 1)
plot(100, 100e-9, 'ro', 'MarkerSize', 10, 'LineWidth', 1)
plot(150, 150e-9, 'ro', 'MarkerSize', 10, 'LineWidth', 1)
hold off
%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%
%GND loop
%%%%%%%%%%%%%%%%%%%%%%%%
GNDloop_data = readmatrix('GNDloop1.csv', 'Delimiter', ';');

GNDloopfrequency = GNDloop_data(:,1);
GNDloopamplitude = GNDloop_data(:,2);


figure(2);
semilogx(GNDloopfrequency, GNDloopamplitude)
grid on
title('GND loop')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
yticks(0:0.1*10^-7:3*10^-7)

hold on
plot(50, 293e-9, 'ro', 'MarkerSize', 10, 'LineWidth', 1);
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 90 minutes allan variance
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN90min_data = readmatrix('Time_Comparisons/5INS 90min allan variance.csv', 'Delimiter', ';');

%Current
FiveAIN90minCURRENTfrequency = FiveAIN90min_data(:,1);
FiveAIN90minCURRENTamplitude = FiveAIN90min_data(:,2);

%GND loop
FiveAIN90minGNDloopfrequency = FiveAIN90min_data(:,3);
FiveAIN90minGNDloopamplitude = FiveAIN90min_data(:,4);

%Power Detector
FiveAIN90minPDETfrequency = FiveAIN90min_data(:,5);
FiveAIN90minPDETamplitude = FiveAIN90min_data(:,6);

%VCC
FiveAIN90minVCCfrequency = FiveAIN90min_data(:,7);
FiveAIN90minVCCamplitude = FiveAIN90min_data(:,8);

%Vd
FiveAIN90minVdfrequency = FiveAIN90min_data(:,9);
FiveAIN90minVdamplitude = FiveAIN90min_data(:,10);


figure(3);
current = semilogx(FiveAIN90minCURRENTfrequency, FiveAIN90minCURRENTamplitude);
hold on
GNDloop = semilogx(FiveAIN90minGNDloopfrequency, FiveAIN90minGNDloopamplitude);
PDET = semilogx(FiveAIN90minPDETfrequency, FiveAIN90minPDETamplitude);
VCC = semilogx(FiveAIN90minVCCfrequency, FiveAIN90minVCCamplitude);
Vd = semilogx(FiveAIN90minVdfrequency, FiveAIN90minVdamplitude);
legend([current, GNDloop, PDET, VCC, Vd], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('Allan Variance with 5 inputs over 90 minutes')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 90 minutes mean history
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN90min_history_data = readmatrix('Time_Comparisons/5INS 90min history mean.csv', 'Delimiter', ';');

%Current
FiveAIN90min_history_CURRENTfrequency = FiveAIN90min_history_data(:,1);
FiveAIN90min_history_CURRENTamplitude = FiveAIN90min_history_data(:,2);

%GND loop
FiveAIN90minGNDloop_history_frequency = FiveAIN90min_history_data(:,5);
FiveAIN90minGNDloop_history_amplitude = FiveAIN90min_history_data(:,6);

%Power Detector
FiveAIN90minPDET_history_frequency = FiveAIN90min_history_data(:,9);
FiveAIN90minPDET_history_amplitude = FiveAIN90min_history_data(:,10);

%VCC
FiveAIN90minVCC_history_frequency = FiveAIN90min_history_data(:,13);
FiveAIN90minVCC_history_amplitude = FiveAIN90min_history_data(:,14);

%Vd
FiveAIN90minVd_history_frequency = FiveAIN90min_history_data(:,15);
FiveAIN90minVd_history_amplitude = FiveAIN90min_history_data(:,16);


figure(4);
currenthistory = semilogx(FiveAIN90min_history_CURRENTfrequency, FiveAIN90min_history_CURRENTamplitude);
hold on
GNDloophistory = semilogx(FiveAIN90minGNDloop_history_frequency, FiveAIN90minGNDloop_history_amplitude);
PDEThistory = semilogx(FiveAIN90minPDET_history_frequency, FiveAIN90minPDET_history_amplitude);
VCChistory = semilogx(FiveAIN90minVCC_history_frequency, FiveAIN90minVCC_history_amplitude);
Vdhistory = semilogx(FiveAIN90minVd_history_frequency, FiveAIN90minVd_history_amplitude);
legend([currenthistory, GNDloophistory, PDEThistory, VCChistory, Vdhistory], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('History mean spectrum graph with 5 inputs over 90 minutes')
xlabel('Time')
ylabel('Amplitude')
yticks(0:0.2*10^-6:7*10^-6)
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 4h allan variance
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN4h_data = readmatrix('Time_Comparisons/5INS 4h allan variance.csv', 'Delimiter', ';');

%Current
FiveAIN4hCURRENTfrequency = FiveAIN4h_data(:,1);
FiveAIN4hCURRENTamplitude = FiveAIN4h_data(:,2);

%GND loop
FiveAIN4hGNDloopfrequency = FiveAIN4h_data(:,3);
FiveAIN4hGNDloopamplitude = FiveAIN4h_data(:,4);

%Power Detector
FiveAIN4hPDETfrequency = FiveAIN4h_data(:,5);
FiveAIN4hPDETamplitude = FiveAIN4h_data(:,6);

%VCC
FiveAIN4hVCCfrequency = FiveAIN4h_data(:,7);
FiveAIN4hVCCamplitude = FiveAIN4h_data(:,8);

%Vd
FiveAIN4hVdfrequency = FiveAIN4h_data(:,9);
FiveAIN4hVdamplitude = FiveAIN4h_data(:,10);


figure(5);
current_4h = semilogx(FiveAIN4hCURRENTfrequency, FiveAIN4hCURRENTamplitude);
hold on
GNDloop_4h = semilogx(FiveAIN4hGNDloopfrequency, FiveAIN4hGNDloopamplitude);
PDET_4h = semilogx(FiveAIN4hPDETfrequency, FiveAIN4hPDETamplitude);
VCC_4h = semilogx(FiveAIN4hVCCfrequency, FiveAIN4hVCCamplitude);
Vd_4h = semilogx(FiveAIN4hVdfrequency, FiveAIN4hVdamplitude);
legend([current_4h, GNDloop_4h, PDET_4h, VCC_4h, Vd_4h], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('Allan Variance with 5 inputs over 4h')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 4h minutes mean history
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN4h_history_data = readmatrix('Time_Comparisons/5INS 4h history mean.csv', 'Delimiter', ';');

%Current
FiveAIN4h_history_CURRENTfrequency = FiveAIN4h_history_data(:,1);
FiveAIN4h_history_CURRENTamplitude = FiveAIN4h_history_data(:,2);

%GND loop
FiveAIN4hGNDloop_history_frequency = FiveAIN4h_history_data(:,5);
FiveAIN4hGNDloop_history_amplitude = FiveAIN4h_history_data(:,6);

%Power Detector
FiveAIN4hPDET_history_frequency = FiveAIN4h_history_data(:,9);
FiveAIN4hPDET_history_amplitude = FiveAIN4h_history_data(:,10);

%VCC
FiveAIN4hVCC_history_frequency = FiveAIN4h_history_data(:,13);
FiveAIN4hVCC_history_amplitude = FiveAIN4h_history_data(:,14);

%Vd
FiveAIN4hVd_history_frequency = FiveAIN4h_history_data(:,15);
FiveAIN4hVd_history_amplitude = FiveAIN4h_history_data(:,16);


figure(6);
currenthistory_4h = semilogx(FiveAIN4h_history_CURRENTfrequency, FiveAIN4h_history_CURRENTamplitude);
hold on
GNDloophistory_4h = semilogx(FiveAIN4hGNDloop_history_frequency, FiveAIN4hGNDloop_history_amplitude);
PDEThistory_4h = semilogx(FiveAIN4hPDET_history_frequency, FiveAIN4hPDET_history_amplitude);
VCChistory_4h = semilogx(FiveAIN4hVCC_history_frequency, FiveAIN4hVCC_history_amplitude);
Vdhistory_4h = semilogx(FiveAIN4hVd_history_frequency, FiveAIN4hVd_history_amplitude);
legend([currenthistory_4h, GNDloophistory_4h, PDEThistory_4h, VCChistory_4h, Vdhistory_4h], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('History mean spectrum graph with 5 inputs over 4h')
xlabel('Time')
ylabel('Amplitude')
yticks(0:0.2*10^-6:7*10^-6)
hold off

%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 16h allan variance
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN16h_data = readmatrix('Time_Comparisons/5INS 16h allan variance.csv', 'Delimiter', ';');

%Current
FiveAIN16hCURRENTfrequency = FiveAIN16h_data(:,1);
FiveAIN16hCURRENTamplitude = FiveAIN16h_data(:,2);

%GND loop
FiveAIN16hGNDloopfrequency = FiveAIN16h_data(:,3);
FiveAIN16hGNDloopamplitude = FiveAIN16h_data(:,4);

%Power Detector
FiveAIN16hPDETfrequency = FiveAIN16h_data(:,5);
FiveAIN16hPDETamplitude = FiveAIN16h_data(:,6);

%VCC
FiveAIN16hVCCfrequency = FiveAIN16h_data(:,7);
FiveAIN16hVCCamplitude = FiveAIN16h_data(:,8);

%Vd
FiveAIN16hVdfrequency = FiveAIN16h_data(:,9);
FiveAIN16hVdamplitude = FiveAIN16h_data(:,10);


figure(7);
current_16h = semilogx(FiveAIN16hCURRENTfrequency, FiveAIN16hCURRENTamplitude);
hold on
GNDloop_16h = semilogx(FiveAIN16hGNDloopfrequency, FiveAIN16hGNDloopamplitude);
PDET_16h = semilogx(FiveAIN16hPDETfrequency, FiveAIN16hPDETamplitude);
VCC_16h = semilogx(FiveAIN16hVCCfrequency, FiveAIN16hVCCamplitude);
Vd_16h = semilogx(FiveAIN16hVdfrequency, FiveAIN16hVdamplitude);
legend([current_16h, GNDloop_16h, PDET_16h, VCC_16h, Vd_16h], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('Allan Variance with 5 inputs over 16h')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%5 AIN 16h minutes mean history
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN16h_history_data = readmatrix('Time_Comparisons/5INS 16h history mean.csv', 'Delimiter', ';');

%Current
FiveAIN16h_history_CURRENTfrequency = FiveAIN16h_history_data(:,1);
FiveAIN16h_history_CURRENTamplitude = FiveAIN16h_history_data(:,2);

%GND loop
FiveAIN16hGNDloop_history_frequency = FiveAIN16h_history_data(:,5);
FiveAIN16hGNDloop_history_amplitude = FiveAIN16h_history_data(:,6);

%Power Detector
FiveAIN16hPDET_history_frequency = FiveAIN16h_history_data(:,9);
FiveAIN16hPDET_history_amplitude = FiveAIN16h_history_data(:,10);

%VCC
FiveAIN16hVCC_history_frequency = FiveAIN16h_history_data(:,13);
FiveAIN16hVCC_history_amplitude = FiveAIN16h_history_data(:,14);

%Vd
FiveAIN16hVd_history_frequency = FiveAIN16h_history_data(:,15);
FiveAIN16hVd_history_amplitude = FiveAIN16h_history_data(:,16);


figure(8);
currenthistory_16h = semilogx(FiveAIN16h_history_CURRENTfrequency, FiveAIN16h_history_CURRENTamplitude);
hold on
GNDloophistory_16h = semilogx(FiveAIN16hGNDloop_history_frequency, FiveAIN16hGNDloop_history_amplitude);
PDEThistory_16h = semilogx(FiveAIN16hPDET_history_frequency, FiveAIN16hPDET_history_amplitude);
VCChistory_16h = semilogx(FiveAIN16hVCC_history_frequency, FiveAIN16hVCC_history_amplitude);
Vdhistory_16h = semilogx(FiveAIN16hVd_history_frequency, FiveAIN16hVd_history_amplitude);
legend([currenthistory_16h, GNDloophistory_16h, PDEThistory_16h, VCChistory_16h, Vdhistory_16h], {'Current', 'GND loop', 'Power Detector', 'VCC', 'Vd'})
grid on
title('History mean spectrum graph with 5 inputs over 4h')
xlabel('Time')
ylabel('Amplitude')
yticks(0:0.2*10^-6:7*10^-6)
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%Comparison of allan variance and mean history graph between 5 minutes, 15 minutes, 30 minutes, 1.5h, 4h, and 16h
%%%%%%%%%%%%%%%%%%%%%%%%
FiveAIN5min_data = readmatrix('Time_Comparisons/5INS 5min allan variance.csv', 'Delimiter', ';');
FiveAIN15min_data = readmatrix('Time_Comparisons/5INS 15min allan variance.csv', 'Delimiter', ';');
FiveAIN30min_data = readmatrix('Time_Comparisons/5INS 30min allan variance.csv', 'Delimiter', ';');
FiveAIN5min_history_data = readmatrix('Time_Comparisons/5INS 5min history mean.csv', 'Delimiter', ';');
FiveAIN15min_history_data = readmatrix('Time_Comparisons/5INS 15min history mean.csv', 'Delimiter', ';');
FiveAIN30min_history_data = readmatrix('Time_Comparisons/5INS 30min history mean.csv', 'Delimiter', ';');


figure(9)
subplot(5, 2, 1)
current_5min = semilogx(FiveAIN5min_data(:,1), FiveAIN5min_data(:,2));
hold on
current_15min = semilogx(FiveAIN15min_data(:,1), FiveAIN15min_data(:,2));
current_30min = semilogx(FiveAIN30min_data(:,1), FiveAIN30min_data(:,2));
current = semilogx(FiveAIN90minCURRENTfrequency, FiveAIN90minCURRENTamplitude);
current_4h = semilogx(FiveAIN4hCURRENTfrequency, FiveAIN4hCURRENTamplitude);
current_16h = semilogx(FiveAIN16hCURRENTfrequency, FiveAIN16hCURRENTamplitude);
legend([current_5min, current_15min, current_30min, current, current_4h, current_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Allan deviation comparison of different time lengths (Current)')
xlabel('Time')
ylabel('Amplitude')
hold off

subplot(5, 2, 3)
GNDloop_5min = semilogx(FiveAIN5min_data(:,3), FiveAIN5min_data(:,4));
hold on
GNDloop_15min = semilogx(FiveAIN15min_data(:,3), FiveAIN15min_data(:,4));
GNDloop_30min = semilogx(FiveAIN30min_data(:,3), FiveAIN30min_data(:,4));
GNDloop = semilogx(FiveAIN90minGNDloopfrequency, FiveAIN90minGNDloopamplitude);
GNDloop_4h = semilogx(FiveAIN4hGNDloopfrequency, FiveAIN4hGNDloopamplitude);
GNDloop_16h = semilogx(FiveAIN16hGNDloopfrequency, FiveAIN16hGNDloopamplitude);
legend([GNDloop_5min, GNDloop_15min, GNDloop_30min, GNDloop, GNDloop_4h, GNDloop_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Allan deviation comparison of different time lengths (GND loop)')
xlabel('Time')
ylabel('Amplitude')
hold off

subplot(5, 2, 5)
PDET_5min = semilogx(FiveAIN5min_data(:,5), FiveAIN5min_data(:,6));
hold on
PDET_15min = semilogx(FiveAIN15min_data(:,5), FiveAIN15min_data(:,6));
PDET_30min = semilogx(FiveAIN30min_data(:,5), FiveAIN30min_data(:,6));
PDET = semilogx(FiveAIN90minPDETfrequency, FiveAIN90minPDETamplitude);
PDET_4h = semilogx(FiveAIN4hPDETfrequency, FiveAIN4hPDETamplitude);
PDET_16h = semilogx(FiveAIN16hPDETfrequency, FiveAIN16hPDETamplitude);
legend([PDET_5min, PDET_15min, PDET_30min, PDET, PDET_4h, PDET_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Allan deviation comparison of different time lengths (Power detector)')
xlabel('Time')
ylabel('Amplitude')
hold off

subplot(5, 2, 7)
VCC_5min = semilogx(FiveAIN5min_data(:,7)*48, FiveAIN5min_data(:,8));
hold on
VCC_15min = semilogx(FiveAIN15min_data(:,7)*48, FiveAIN15min_data(:,8));
VCC_30min = semilogx(FiveAIN30min_data(:,7)*48, FiveAIN30min_data(:,8));
VCC = semilogx(FiveAIN90minVCCfrequency*48, FiveAIN90minVCCamplitude);
VCC_4h = semilogx(FiveAIN4hVCCfrequency*48, FiveAIN4hVCCamplitude);
VCC_16h = semilogx(FiveAIN16hVCCfrequency*48, FiveAIN16hVCCamplitude);
legend([VCC_5min, VCC_15min, VCC_30min, VCC, VCC_4h, VCC_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Allan deviation comparison of different time lengths (VCC)')
xlabel('Time')
ylabel('Amplitude')
hold off

subplot(5, 2, 9)
Vd_5min = semilogx(FiveAIN5min_data(:,9)*48, FiveAIN5min_data(:,10));
hold on
Vd_15min = semilogx(FiveAIN15min_data(:,9)*48, FiveAIN15min_data(:,10));
Vd_30min = semilogx(FiveAIN30min_data(:,9)*48, FiveAIN30min_data(:,10));
Vd = semilogx(FiveAIN90minVdfrequency*48, FiveAIN90minVdamplitude);
Vd_4h = semilogx(FiveAIN4hVdfrequency*48, FiveAIN4hVdamplitude);
Vd_16h = semilogx(FiveAIN16hVdfrequency*48, FiveAIN16hVdamplitude);
legend([Vd_5min, Vd_15min, Vd_30min, Vd, Vd_4h, Vd_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Allan deviation comparison of different time lengths (Vd)')
xlabel('Time')
ylabel('Amplitude')
hold off

subplot(5, 2, 2)
currenthistory_5min = semilogx(FiveAIN5min_history_data(:,1), FiveAIN5min_history_data(:,2));
hold on
currenthistory_15min = semilogx(FiveAIN15min_history_data(:,1), FiveAIN15min_history_data(:,2));
currenthistory_30min = semilogx(FiveAIN30min_history_data(:,1), FiveAIN30min_history_data(:,2));
currenthistory = semilogx(FiveAIN90min_history_CURRENTfrequency, FiveAIN90min_history_CURRENTamplitude);
currenthistory_4h = semilogx(FiveAIN4h_history_CURRENTfrequency, FiveAIN4h_history_CURRENTamplitude);
currenthistory_16h = semilogx(FiveAIN16h_history_CURRENTfrequency, FiveAIN16h_history_CURRENTamplitude);
legend([currenthistory_5min, currenthistory_15min, currenthistory_30min, currenthistory, currenthistory_4h, currenthistory_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Mean history graph comparison of different time lengths (Current)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off

subplot(5, 2, 4)
GNDloophistory_5min = semilogx(FiveAIN5min_history_data(:,5), FiveAIN5min_history_data(:,6));
hold on
GNDloophistory_15min = semilogx(FiveAIN15min_history_data(:,5), FiveAIN15min_history_data(:,6));
GNDloophistory_30min = semilogx(FiveAIN30min_history_data(:,5), FiveAIN30min_history_data(:,6));
GNDloophistory = semilogx(FiveAIN90minGNDloop_history_frequency, FiveAIN90minGNDloop_history_amplitude);
GNDloophistory_4h = semilogx(FiveAIN4hGNDloop_history_frequency, FiveAIN4hGNDloop_history_amplitude);
GNDloophistory_16h = semilogx(FiveAIN16hGNDloop_history_frequency, FiveAIN16hGNDloop_history_amplitude);
legend([GNDloophistory_5min, GNDloophistory_15min, GNDloophistory_30min, GNDloophistory, GNDloophistory_4h, GNDloophistory_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Mean history graph comparison of different time lengths (GND loop)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off

subplot(5, 2, 6)
PDEThistory_5min = semilogx(FiveAIN5min_history_data(:,9), FiveAIN5min_history_data(:,10));
hold on
PDEThistory_15min = semilogx(FiveAIN15min_history_data(:,9), FiveAIN15min_history_data(:,10));
PDEThistory_30min = semilogx(FiveAIN30min_history_data(:,9), FiveAIN30min_history_data(:,10));
PDEThistory = semilogx(FiveAIN90minPDET_history_frequency, FiveAIN90minPDET_history_amplitude);
PDEThistory_4h = semilogx(FiveAIN4hPDET_history_frequency, FiveAIN4hPDET_history_amplitude);
PDEThistory_16h = semilogx(FiveAIN16hPDET_history_frequency, FiveAIN16hPDET_history_amplitude);
legend([PDEThistory_5min, PDEThistory_15min, PDEThistory_30min, PDEThistory, PDEThistory_4h, PDEThistory_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Mean history graph comparison of different time lengths (Power detector)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off

subplot(5, 2, 8)
VCChistory_5min = semilogx(FiveAIN5min_history_data(:,13)*48, FiveAIN5min_history_data(:,14));
hold on
VCChistory_15min = semilogx(FiveAIN15min_history_data(:,13)*48, FiveAIN15min_history_data(:,14));
VCChistory_30min = semilogx(FiveAIN30min_history_data(:,13)*48, FiveAIN30min_history_data(:,14));
VCChistory = semilogx(FiveAIN90minVCC_history_frequency*48, FiveAIN90minVCC_history_amplitude);
VCChistory_4h = semilogx(FiveAIN4hVCC_history_frequency*48, FiveAIN4hVCC_history_amplitude);
VCChistory_16h = semilogx(FiveAIN16hVCC_history_frequency*48, FiveAIN16hVCC_history_amplitude);
legend([VCChistory_5min, VCChistory_15min, VCChistory_30min, VCChistory, VCChistory_4h, VCChistory_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Mean history graph comparison of different time lengths (VCC)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off

subplot(5, 2, 10)
Vdhistory_5min = semilogx(FiveAIN5min_history_data(:,15)*48, FiveAIN5min_history_data(:,16));
hold on
Vdhistory_15min = semilogx(FiveAIN15min_history_data(:,15)*48, FiveAIN15min_history_data(:,16));
Vdhistory_30min = semilogx(FiveAIN30min_history_data(:,15)*48, FiveAIN30min_history_data(:,16));
Vdhistory = semilogx(FiveAIN90minVd_history_frequency*48, FiveAIN90minVd_history_amplitude);
Vdhistory_4h = semilogx(FiveAIN4hVd_history_frequency*48, FiveAIN4hVd_history_amplitude);
Vdhistory_16h = semilogx(FiveAIN16hVd_history_frequency*48, FiveAIN16hVd_history_amplitude);
legend([Vdhistory_5min, Vdhistory_15min, Vdhistory_30min, Vdhistory, Vdhistory_4h, Vdhistory_16h], {'5min', '15min', '30min', '1.5h', '4h', '16h'})
grid on
title('Mean history graph comparison of different time lengths (Vd)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off
%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%Comparison of allan variance and mean history graph between using 1AIN and
%using 5AIN
%%%%%%%%%%%%%%%%%%%%%%%%
ONEAIN90min_data = readmatrix('1ainVS5ain/1INS 90min allan variance', 'Delimiter', ';');
ONEAIN90min_history_data = readmatrix('1ainVS5ain/1INS 90min history mean', 'Delimiter', ';');

%Allan variance PDET
OneAIN90minPDETfrequency = ONEAIN90min_data(:,1);
OneAIN90minPDETamplitude = ONEAIN90min_data(:,2);

%History mean PDET
OneAIN90minPDETfrequency_history = ONEAIN90min_history_data(:,9);
OneAIN90minPDETamplitude_history = ONEAIN90min_history_data(:,10);


figure(10)
subplot(2, 1, 1)
PDET = semilogx(FiveAIN90minPDETfrequency, FiveAIN90minPDETamplitude);
hold on
PDET_1AIN = semilogx(OneAIN90minPDETfrequency, OneAIN90minPDETamplitude);
legend([PDET, PDET_1AIN], {'5AIN', '1AIN'})
grid on
title('Comparison of Allan variance between using 5AIN and 1AIN (Power detector)')
xlabel('Time')
ylabel('Amplitude')
xlim([10e-4 10e3])
ylim([-100 -70])
hold off


subplot(2, 1, 2)
PDEThistory = semilogx(FiveAIN90minPDET_history_frequency, FiveAIN90minPDET_history_amplitude);
hold on
PDET_1AIN_history = semilogx(OneAIN90minPDETfrequency_history, OneAIN90minPDETamplitude_history);
legend([PDEThistory, PDET_1AIN_history], {'5AIN', '1AIN'})
grid on
title('Comparison of history mean between using 5AIN and 1AIN (Power detector)')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
hold off

%%%%%%%%%%%%%%%%%%%%%%%%
%227 Ohm varistor output measurement (for simulation comparison)
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%

Varistor_history_data = readmatrix('Varistor Mean History.csv', 'Delimiter', ';');

figure(11);
semilogx(Varistor_history_data(:,13), Varistor_history_data(:,14));
legend('GUH:)')
grid on
title('GOGI')
xlabel('Frequency [Hz]')
ylabel('Amplitude')
yticks(0:0.1*10^-7:2*10^-7)
hold off
