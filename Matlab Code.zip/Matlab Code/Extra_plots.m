SS_AllanVariance = readmatrix('S+vsS-/Allan Varience S+ to S-.csv', 'Delimiter', ';');
SS_DClevel = readmatrix('S+vsS-/DC level for S+ to S-.csv', 'Delimiter', ';');
SS_history = readmatrix('S+vsS-/history mean for S+ to S-.csv', 'Delimiter', ';');

figure(1)
subplot(2, 1, 1)
semilogx(SS_AllanVariance(:,3), SS_AllanVariance(:,4));
title('Allan Variance of Instrumentational Amplifier')
xlabel('Time')
ylabel('Amplitude')
grid on

subplot(2, 1, 2)
PSD_amp = semilogx(SS_history(:,1), SS_history(:,2));
title('PSD graph of Instrumentational Amplifier')
hold on
Hz50 = plot(49.99, 2*10^-6, 'ro');
Hz150 = plot(149.96, 1.41*10^-6, 'ko');
legend([PSD_amp, Hz50, Hz150], 'Instrumentational Amplifier', '50 Hz noise', '150 Hz noise')
xlabel('Frequency')
ylabel('Amplitude')
grid on
hold off


LT6221_1206_mean = readmatrix('LT6221/Mean History 1206.csv', 'Delimiter', ';');
LT6221_1206_Avar = readmatrix('LT6221/Allan Variance 1206.csv', 'Delimiter', ';');

%LT6221_0805_DC_VCC_f = LT6221_0805_DC(:,13);
%LT6221_0805_DC_VCC_amp = (4/0.916)*LT6221_0805_DC(:,14);

figure(2)
subplot(2, 1, 1)
semilogx(LT6221_1206_Avar(:,9), LT6221_1206_Avar(:,10) + 20*log10(4/0.916));
title('Allan Variance')
ylim([-100 -70])
grid on

subplot(2, 1, 2)
semilogx(LT6221_1206_mean(:,13), (4/0.916)*LT6221_1206_mean(:,14));
title('PSD graph')
grid on




figure(3)
subplot(3, 1, 1)
semilogx(LT6221_1206_Avar(:,7), LT6221_1206_Avar(:,8));
title('Allan Variance')
ylim([-145 -110])
grid on

subplot(3, 1, 2)
graph = semilogx(LT6221_1206_mean(:,5), LT6221_1206_mean(:,6));
hold on
MUX = plot(11.83, 6.4*10^-8, 'ko');
powergrid = plot(49.98, 1.3*10^-7, 'ro');
%hold off
title('PSD GND graph with 5AIN')
legend([graph, MUX, powergrid], 'GND loop', 'MUX', 'Power Grid', 'location', 'north')
xlim([10^-2 10^2])
ylim([0 3.5*10^-7])
grid on
hold off

GND = readmatrix('GNDloop1.csv', 'Delimiter', ';');
subplot(3, 1, 3)
graph1 = semilogx(GND(:,1), GND(:,2));
hold on
powergrid1 = plot(49.93, 2.93*10^-7, 'ro');
hold off
title('PSD GND graph with 1AIN')
legend([graph1, powergrid1], 'GND loop', 'Power Grid', 'location', 'north')
xlim([10^-2 10^2])
ylim([0 3.5*10^-7])
grid on


GNDloop1AIN_mean = readmatrix('GND loop/GND loop Mean history.csv');
GNDloop1AIN_Avar = readmatrix('GND loop/GND loop Allan variance.csv');

figure(4)
subplot(2, 1, 1)
graph = semilogx(LT6221_1206_mean(:,5), LT6221_1206_mean(:,6));
hold on
MUX = plot(11.83, 6.4*10^-8, 'ko');
powergrid = plot(49.98, 1.3*10^-7, 'ro');
graph1 = semilogx(GNDloop1AIN_mean(:,5), GNDloop1AIN_mean(:,6));
powergrid1 = plot(49.98, 6.87*10^-8, 'go');
title('GND loop difference when 5AIN and 1AIN are used')
legend([graph, graph1, powergrid, powergrid1, MUX], '5AIN GND loop', '1AIN GND loop', '5AIN 50 Hz', '1AIN 50 Hz', 'MUX 41 Hz', 'location', 'northwest')
yticks(0:0.1*10^-7:3*10^-7)
xlabel('Frequency')
ylabel('Amplitude')
grid on
hold off

subplot(2, 1, 2)
graph_Avar = semilogx(LT6221_1206_Avar(:,7), LT6221_1206_Avar(:,8));
hold on
graph1_AVAR = semilogx(GNDloop1AIN_Avar(:,1), GNDloop1AIN_Avar(:,2));
title('GND loop difference when 5AIN and 1AIN are used')
legend([graph_Avar, graph1_AVAR], '5AIN GND loop', '1AIN GND loop')
xlabel('Time')
ylabel('Amplitude')
grid on
hold off





min5_avar = readmatrix('TimeDiffs/5min/Allan Variance 1206 5min.csv', 'Delimiter', ';');
min15_avar = readmatrix('TimeDiffs/15min/Allan Variance 1206 15min.csv', 'Delimiter', ';');
min30_avar = readmatrix('TimeDiffs/30min/Allan Variance 1206 30min.csv', 'Delimiter', ';');
min90_avar = readmatrix('TimeDiffs/90min/Allan Variance 1206 90min.csv', 'Delimiter', ';');
min4h_avar = readmatrix('TimeDiffs/4h/Allan Variance 1206 4h.csv', 'Delimiter', ';');
min16h_avar = readmatrix('TimeDiffs/16h/Allan Variance 1206 16h.csv', 'Delimiter', ';');


min5_mean = readmatrix('TimeDiffs/5min/Mean History 1206 5min.csv', 'Delimiter', ';');
min15_mean = readmatrix('TimeDiffs/15min/Mean History 1206 15min.csv', 'Delimiter', ';');
min30_mean = readmatrix('TimeDiffs/30min/Mean History 1206 30min.csv', 'Delimiter', ';');
min90_mean = readmatrix('TimeDiffs/90min/Mean History 1206 90min.csv', 'Delimiter', ';');
min4h_mean = readmatrix('TimeDiffs/4h/Mean History 1206 4h.csv', 'Delimiter', ';');
min16h_mean = readmatrix('TimeDiffs/16h/Mean History 1206 16h.csv', 'Delimiter', ';');




figure(6)
subplot(2, 1, 1)
m5 = semilogx(min5_avar(:,11), min5_avar(:,12) + 20*log10(2/0.891));
hold on
m15 = semilogx(min15_avar(:,11), min15_avar(:,12) + 20*log10(2/0.891));
m30 = semilogx(min30_avar(:,11), min30_avar(:,12) + 20*log10(2/0.891));
m90 = semilogx(min90_avar(:,17), min90_avar(:,18) + 20*log10(2/0.891));
h4 = semilogx(min4h_avar(:,11), min4h_avar(:,12) + 20*log10(2/0.891));
h16 = semilogx(min16h_avar(:,11), min16h_avar(:,12) + 20*log10(2/0.891));
hold off
legend([m5, m15, m30, m90, h4, h16], '5 min', '15 min', '30 min', '90 min', '4 h', '16 h')
title('Allan Variance of Vd during different time lengths')
xlabel('Time')
ylabel('Amplitude')
grid on

subplot(2, 1, 2)
m5_his = semilogx(min5_mean(:,15), (2/0.916)*min5_mean(:,16));
hold on
m15_his = semilogx(min15_mean(:,15), (2/0.916)*min15_mean(:,16));
m30_his = semilogx(min30_mean(:,15), (2/0.916)*min30_mean(:,16));
m90_his = semilogx(min90_mean(:,15), (2/0.916)*min90_mean(:,16)); 
h4_his = semilogx(min4h_mean(:,15), (2/0.916)*min4h_mean(:,16)); 
h16_his = semilogx(min16h_mean(:,15), (2/0.916)*min16h_mean(:,16));
hold off
legend([m5_his, m15_his, m30_his, m90_his, h4_his, h16_his], '5 min', '15 min', '30 min', '90 min', '4 h', '16 h')
title('PSD graph of Vd during different time lengths')
xlabel('Frequency')
ylabel('Amplitude')
grid on


for noise_generator = 1
    NG_Avar = readmatrix('Noise Generator/Allan Variance LT6221 1206 no MMIC.csv', 'Delimiter', ';');
    NG_DC = readmatrix('Noise Generator/DC Level LT6221 1206 no MMIC.csv', 'Delimiter', ';');
    NG_mean = readmatrix('Noise Generator/Mean History LT6221 1206 no MMIC.csv', 'Delimiter', ';');

    figure(7)
    subplot(2, 1, 1)
    semilogx(NG_Avar(:,5), NG_Avar(:,6) + 20*log10(2.859/2.7));
    title('Allan Variance of Noise Generator')
    xlabel('Time')
    ylabel('Amplitude')
    grid on
    subplot(2, 1, 2)
    semilogx(NG_mean(:,3), (2.859/2.7)*NG_mean(:,4));
    title('PSD of Noise Generator')
    xlabel('Frequency')
    ylabel('Amplitude')
    grid on

end

for PWR_supply = 1
    PWR_Avar = readmatrix('Power Supply Noise/Allan Variance 1206 30min 1000sample per s.csv', 'Delimiter', ';');
    PWR_DC = readmatrix('Power Supply Noise/DC Level 1206 1000sample per s.csv', 'Delimiter', ';');
    PWR_mean = readmatrix('Power Supply Noise/Mean History 1206 1000sample per s.csv', 'Delimiter', ';');

    figure(8)
    subplot(2, 1, 1)
    semilogx(PWR_Avar(:,1), PWR_Avar(:,2) + 20*log10(4/0.916));
    title('Allan Variance of Power Supply')
    xlabel('Time')
    ylabel('Amplitude')
    grid on

    subplot(2, 1, 2)
    graph = semilogx(PWR_mean(:,13), (4/0.916)*PWR_mean(:,14));
    title('PSD of Power Supply')
    xlabel('Frequency')
    ylabel('Amplitude')
    ylim([0 3E-5])
    xlim([0.1 400])

    hold on
    hz41 = plot(41.26, 3.8E-6, 'ro');
    hz50 = plot(50.05, 4.96E-6, 'ko');
    hz100 = plot(99.98, 3.1E-6, 'mo');
    hz150 = plot(150, 2.77E-6, 'go');

    legend([graph, hz41, hz50, hz100, hz150], 'PSD of Power Supply', '41 Hz', '50 Hz', '100 Hz', '150 Hz')
    hold off

    grid on
end

%for PWR_supply_to_Amp = 1
  %  PWR__toAMp_mean = readmatrix('PWR supply to amp/Allan Varience.csv', 'Delimiter', ';');
  %  PWR_toAmp_Avar = readmatrix('PWR supply to amp/history mean.csv', 'Delimiter', ';');
%
%
  %  figure(9)
  %  subplot(2, 1, 1)
  %  semilogx(PWR__toAMp_mean(:,1), PWR__toAMp_mean(:,2));
  %  title('Allan Variance of Power Supply')
  %  xlabel('Time')
  %  ylabel('Amplitude')
  %  grid on
%
  %  subplot(2, 1, 2)
  %  semilogx(PWR__toAMp_Avar(:,3), PWR__toAMp_Avar(:,4));
  %  title('PSD of Power Supply')
  %  xlabel('Frequency')
  %  ylabel('Amplitude')
  %  grid on

%end


%1AIN different sample speeds (Every input is for the PDET)
PS_1206_60Hz_PDET_LT6221_avar = readmatrix('SampleSpeed/Allan Variance 1206 60Hz.csv', 'Delimiter', ';');
PS_1206_1000Hz_PDET_LT6221_avar = readmatrix('SampleSpeed/Allan Variance 1206 1000Hz.csv', 'Delimiter', ';');
PS_1206_3750Hz_PDET_LT6221_avar = readmatrix('SampleSpeed/Allan Variance 1206 3750Hz.csv', 'Delimiter', ';');
PS_1206_60Hz_PDET_LT6221_mean = readmatrix('SampleSpeed/Mean History 1206 60Hz.csv', 'Delimiter', ';');
PS_1206_1000Hz_PDET_LT6221_mean = readmatrix('SampleSpeed/Mean History 1206 1000Hz.csv', 'Delimiter', ';');
PS_1206_3750Hz_PDET_LT6221_mean = readmatrix('SampleSpeed/Mean History 1206 3750Hz.csv', 'Delimiter', ';');

figure(10)
subplot(2, 1, 1)
Hz60_Avar_PDET = semilogx(PS_1206_60Hz_PDET_LT6221_avar(:,1), PS_1206_60Hz_PDET_LT6221_avar(:,2) + 20*log10(2/0.891));
hold on
Hz1000_Avar_PDET = semilogx(PS_1206_1000Hz_PDET_LT6221_avar(:,1), PS_1206_1000Hz_PDET_LT6221_avar(:,2) + 20*log10(2/0.891));
Hz3750_Avar_PDET = semilogx(PS_1206_3750Hz_PDET_LT6221_avar(:,1), PS_1206_3750Hz_PDET_LT6221_avar(:,2) + 20*log10(2/0.891));
hold off
title('Allan variance of PDET with different sampling frequencies')
xlabel('Time')
ylabel('Amplitude')
legend([Hz60_Avar_PDET, Hz1000_Avar_PDET, Hz3750_Avar_PDET], '60 Hz', '1000 Hz', '3750 Hz')
grid on

subplot(2, 1, 2)
Hz60_mean_PDET = semilogx(PS_1206_60Hz_PDET_LT6221_mean(:,3), (2/0.891)*PS_1206_60Hz_PDET_LT6221_mean(:,4));
hold on
Hz1000_mean_PDET = semilogx(PS_1206_1000Hz_PDET_LT6221_mean(:,3), (2/0.891)*PS_1206_1000Hz_PDET_LT6221_mean(:,4));
Hz3750_mean_PDET = semilogx(PS_1206_3750Hz_PDET_LT6221_mean(:,3), (2/0.891)*PS_1206_3750Hz_PDET_LT6221_mean(:,4));
hold off
title('PSD of PDET with different sampling frequencies')
xlabel('Frequency')
ylabel('Amplitude')
legend([Hz60_mean_PDET, Hz1000_mean_PDET, Hz3750_mean_PDET], '60 Hz', '1000 Hz', '3750 Hz')
grid on

